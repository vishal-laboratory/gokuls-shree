 <!DOCTYPE html>
<html>
<head>
<title>Gokulshree School Of Management And Technology Private Limited</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="images/favicon.png">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<META HTTP-EQUIV="EXPIRES" CONTENT="0">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Gokulshree School Of Management And Technology Private Limited is one of the best Institute  in  Shrawasti -Uttar Pradesh -271831 where many of courses are available for students to join for making their career better. Apply Now!">
<meta name="keywords" content="Institutes in  Shrawasti -Uttar Pradesh -271831, Best Institute, Best College, Institute in  Shrawasti -Uttar Pradesh -271831">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/revolution-slider.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/responsive.css">

<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "Gokulshree School Of Management And Technology Private Limited",
  "url": "https://gokulshreeschool.com",
  "sameAs": [
    "https://www.facebook.com/",
    "https://twitter.com",
    "https://linkedin.com/",
    "https://plus.google.com/"
  ],
  "logo": "https://gokulshreeschool.com/images/logo.png",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "+91-9628281020",
    "contactType": "Customer Support :"
  }]
}
</script>
<script type="text/javascript">
function getXMLHTTP() { 
		var xmlhttp=false;	
		try{
			xmlhttp=new XMLHttpRequest();
		}
		catch(e)	{		
			try{			
				xmlhttp= new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e){
				try{
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
				}
				catch(e1){
					xmlhttp=false;
				}
			}
		}
		 	
		return xmlhttp;
    }
	
	function find_courses(subid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_courses.php?cid="+subid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('courses_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}
function find_batch(batchid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_batch.php?bid="+batchid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('batch_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}

	function find_district(subid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_district.php?cid="+subid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('district_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}
	
	function find_branch(subid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_branch.php?cid="+subid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('branch_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}



</script>
</head>
<body>
<div class="page-wrapper">
<header class="main-header header-style-one">
        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container clearfix">
<!--Top Left-->
 <div class="column col-lg-8 col-md-8 col-sm-12 col-xs-12">
<center>             
<style>
.text-white {
    color: #fff !important;
}
.list-inline {
padding-left: 0;
margin-left: -5px;
list-style: none;
}
.list-inline>li {
    display: inline-block;
    margin-top: 5px;
	 margin-bottom: 5px;
    padding-right: 10px;
  margin-left:4px;
    font-weight: 800;
    background-color:#D9EEE1;
    border-radius: 10px;
}
.pl-10 {
    padding-left: 10px !important;
}
.text-black {
    color: #000 !important;
}
.list-inline>li:hover {
    background: #FFF4A3;
}
					</style>
			<ul class="list-inline sm-pull-none sm-text-center text-white mb-sm-20 mt-10" style="font-size:14px;padding-inline-start: 1px;">
      
			 <li class=" pl-10"><a href="contact-us.php" class="text-black"> Enquiry Here</a></li>
			 <li class=" pl-10"><a href="franchise.php" class="text-black">Franchise Details</a></li>
			  <li class=" pl-10"><a href="franchise-enquiry.php" class="text-black">Apply Franchise</a></li>
			  <li class=" pl-10"><a href="new" target="_blank" class="text-black">Franchise Login</a></li>
			   <li class=" pl-10"><a href="new" target="_blank" class="text-black"> Employee Login</a></li>
			  <li class="pl-10"><a href="login.php" class="text-black">Student Login</a></li>

			  
			 <!--<a href="new" class="text-white m-0 pl-10 mt-0" target="_blank"><span class="btn btn-theme-colored2 btn-xs">Login</span></a>-->  
			 
			 </ul>
             </center>  
				</div>
                <!--Top Right-->
				     <div class="column col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <center>
                    <ul class="links-nav clearfix" style="margin-top:10px;">
                       <li><a href="tell:+91-9628281020" target="_blank" style="color:#fff;"><span class=" fa fa-phone"></span>+91-9628281020</a></li>
                        <li><a href="https://www.facebook.com" target="_blank"><span class=" fa fa-facebook"></span></a></li>
                        <li><a href="https://twitter.com" target="_blank"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="https://www.youtube.com" target="_blank"><span class="fa fa-youtube"></span></a></li>
                        <li><a href="http://www.linkedin.com" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                    </ul>
              </center>
				</div>
            </div>
        </div>
        <!-- Header Top End -->
        <!--Header-Upper-->
        <div class="header-upper">
            <div class="auto-container">
                <div class="clearfix">
                    <div class="pull-left logo-outer">
                        <div class="logo">
						<a href="index.php">
						<img src="images/head.png" alt="Gokulshree School Of Management And Technology Private Limited logo" style="margin-top:5px; margin-bottom:5px;">
						</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
        <!--Header-Lower-->
        <div class="header-lower">
            <div class="auto-container">
                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                        <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                        <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                    <li><a href="verification.php">Student Verification</a></li>
					<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					<li><a href="placement.php">Placement</a></li>
						
						
			
                         </ul>
                                </li>
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                        
                             <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						
						
						
                         </ul>
                                </li>
								<li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                                </li>
								
								
                               
                                
                                <li><a href=""></a></li>
                            
                            	<li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
                             <li><a href="contact-us.php">Contact Us</a></li>
							  <li><a href="find_branch.php">Find Branch</a></li>
							  
						
						
                         </ul>
                                </li>
                            
                            
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                    <div class="btn-outer"><a href="franchise-enquiry.php" class="theme-btn quote-btn"><span class="fa fa-user"></span> Apply Franchise </a></div>
                </div>
            </div>
        </div>
        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.php" class="img-responsive"><img src="images/logo-small.png" alt="Gokulshree School Of Management And Technology Private Limited"></a>
                </div>
                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                      <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                     <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                                      
						<li><a href="verification.php">Student Verification</a></li>
						<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					
						<li><a href="placement.php">Placement</a></li>
                         </ul>
                                </li>
								
									<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                    <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						<li><a href="why_gbge.php">Why GBGE</a></li>
							
						
						
						
                         </ul>
                                </li>
								 <li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
                                 
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                             </li>
                               <li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
							<li><a href="contact-us.php">Contact Us</a></li>
							 <li><a href="find_branch.php">Find Branch</a></li>
							 </ul>
							 </li>
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                </div>
            </div>
        </div>
        <!--End Sticky Header-->
    </header><!--End Main Header -->
<!--Main Slider-->
 <section class="page-title" style="background-image:url(images/page-title.jpg);">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Title -->
                <div class="title-column col-md-6 col-sm-12 col-xs-12">
                    <h1>Franchise Enquiry</h1>
                </div>
                <!--Bread Crumb -->
                <div class="breadcrumb-column col-md-6 col-sm-12 col-xs-12">
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Franchise Enquiry</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--End Page Title-->
    <!--About Section-->
    <section class="about-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Column-->
                <div class="column col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="about-content-box">
      <form action=""   method="post" enctype="multipart/form-data" name="form1"	style="padding:15px;">
             <style>
                 .col-md-4{
                     margin-top:5px;
                     margin-bottom:5px;
                 }
                 .col-md-6{
                     margin-top:5px;
                     margin-bottom:5px;
                 }
                 .form-control{
                   margin-top:5px;  
                 }
             </style>
<div id="page-inner">
<hr>
<div class="row">
<div class="col-md-12 headerTitle"><strong style="color:#00CC00;font-size:18px;"> Personal Information</strong></div>
</div>

<div class="row">
<div class="col-md-4"><strong style="color:#003366;">Your First Name</strong>
<input name="first-name" type="text"  class="form-control" required>
</div>	

<div class="col-md-4"><strong style="color:#003366;">Your Last Name</strong>
<input name="last-name" type="text"  class="form-control">
</div>

<div class="col-md-4"><strong style="color:#003366;">Phone No</strong>
<input name="phone-no" type="text" class="form-control">
</div>
 </div>

<div class="row">
<div class="col-md-4"><strong style="color:#003366;">Mobile Number</strong>
<input name="mobile-no" maxlength="10" required type="text"  class="form-control">
</div>

<div class="col-md-4"><strong style="color:#003366;">Email Account</strong> 
<input name="email" required type="email" class="form-control">

</div>

<div class="col-md-4"><strong style="color:#003366;">Gender</strong>
<select name="gender"required class="form-control">
<option value="0">Select Gender</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>
</div>
</div>

<div class="row">
<div class="col-md-12"><strong style="color:#00CC00; font-size:18px;">Organization Information</strong></div>
</div>
<div class="row">
<div class="col-md-12"><strong style="color:#003366;">Organization Details</strong>
<input name="organization-details" type="text" class="form-control" required>
</div>

</div>

<div class="row">
<div class="col-md-12 headerTitle"><strong style="color:#00CC00; font-size:18px;">Contact Information</strong></div>
<div class="col-md-6"><strong style="color:#003366;">Address Village/AREA/LOCATION </strong>
<input name="address" type="text" class="form-control" required>
</div>
<div class="col-md-6"><strong style="color:#003366;">Address Block</strong>
<input name="address1" type="text"  class="form-control">
</div>
<div class="col-md-6">
<strong style="color:#003366;"> State</strong><br>
<select onChange="find_district(this.value)"  name="state" class="form-control"  >
<option value="">Select</option>
<option value="1" >Andaman and Nicobar Island (UT)</option>
<option value="2" >Andhra Pradesh</option>
<option value="3" >Arunachal Pradesh</option>
<option value="4" >Assam</option>
<option value="5" >Bihar</option>
<option value="6" >Chandigarh (UT)</option>
<option value="7" >Chhattisgarh</option>
<option value="8" >Dadra and Nagar Haveli (UT)</option>
<option value="9" >Daman and Diu (UT)</option>
<option value="10" >Delhi (NCT)</option>
<option value="11" >Goa</option>
<option value="12" >Gujarat</option>
<option value="13" >Haryana</option>
<option value="14" >Himachal Pradesh</option>
<option value="15" >Jammu and Kashmir</option>
<option value="16" >Jharkhand</option>
<option value="17" >Karnataka</option>
<option value="18" >Kerala</option>
<option value="19" >Lakshadweep (UT)</option>
<option value="20" >Madhya Pradesh</option>
<option value="21" >Maharashtra</option>
<option value="22" >Manipur</option>
<option value="23" >Meghalaya</option>
<option value="24" >Mizoram</option>
<option value="25" >Nagaland</option>
<option value="26" >Odisha</option>
<option value="27" >Puducherry (UT)</option>
<option value="28" >Punjab</option>
<option value="29" >Rajastha</option>
<option value="30" >Sikkim</option>
<option value="31" >Tamil Nadu</option>
<option value="32" >Telangana</option>
<option value="33" >Tripura</option>
<option value="34" >Uttarakhand</option>
<option value="35" >Uttar Pradesh</option>
<option value="36" >West Bengal</option>
</select>
<span class="red" style="color:red;"> </span> 
</div>
<div class="col-md-6" ><strong style="color:#003366;"> District</strong><br>
<div  id="district_div">
<select name="district" style="padding:5px;"  class="form-control" >
<option value="">Select</option>
<option value="1" >North and Middle Andama</option>
<option value="2" >South Andama</option>
<option value="3" >Nicobar</option>
<option value="4" >Anantapur</option>
<option value="5" >Chittoor</option>
<option value="6" >East Godavari</option>
<option value="7" >Guntur</option>
<option value="8" >Krishna</option>
<option value="9" >Kurnool</option>
<option value="10" >Prakasam</option>
<option value="11" >Srikakulam</option>
<option value="12" >Sri Potti Sri Ramulu Nellore</option>
<option value="13" >Vishakhapatnam</option>
<option value="14" >Vizianagaram</option>
<option value="15" >West Godavari</option>
<option value="16" >Cudappah</option>
<option value="17" >Anjaw</option>
<option value="18" >Changlang</option>
<option value="19" >East Siang</option>
<option value="20" >East Kameng</option>
<option value="21" >Kurung Kumey</option>
<option value="22" >Lohit</option>
<option value="23" >Lower Dibang Valley</option>
<option value="24" >Lower Subansiri</option>
<option value="25" >Papum Pare</option>
<option value="26" >Tawang</option>
<option value="27" >Tirap</option>
<option value="28" >Dibang Valley</option>
<option value="29" >Upper Siang</option>
<option value="30" >Upper Subansiri</option>
<option value="31" >West Kameng</option>
<option value="32" >West Siang</option>
<option value="33" >Baksa</option>
<option value="34" >Barpeta</option>
<option value="35" >Bongaigao</option>
<option value="36" >Cachar</option>
<option value="37" >Chirang</option>
<option value="38" >Darrang</option>
<option value="39" >Dhemaji</option>
<option value="40" >Dima Hasao</option>
<option value="41" >Dhubri</option>
<option value="42" >Dibrugarh</option>
<option value="43" >Goalpara</option>
<option value="44" >Golaghat</option>
<option value="45" >Hailakandi</option>
<option value="46" >Jorhat</option>
<option value="47" >Kamrup</option>
<option value="48" >Kamrup Metropolita</option>
<option value="49" >Karbi Anglong</option>
<option value="50" >Karimganj</option>
<option value="51" >Kokrajhar</option>
<option value="52" >Lakhimpur</option>
<option value="53" >Morigao</option>
<option value="54" >Nagao</option>
<option value="55" >Nalbari</option>
<option value="56" >Sivasagar</option>
<option value="57" >Sonitpur</option>
<option value="58" >Tinsukia</option>
<option value="59" >Udalguri</option>
<option value="60" >Araria</option>
<option value="61" >Arwal</option>
<option value="62" >Aurangabad</option>
<option value="63" >Banka</option>
<option value="64" >Begusarai</option>
<option value="65" >Bhagalpur</option>
<option value="66" >Bhojpur</option>
<option value="67" >Buxar</option>
<option value="68" >Darbhanga</option>
<option value="69" >East Champara</option>
<option value="70" >Gaya</option>
<option value="71" >Gopalganj</option>
<option value="72" >Jamui</option>
<option value="73" >Jehanabad</option>
<option value="74" >Kaimur</option>
<option value="75" >Katihar</option>
<option value="76" >Khagaria</option>
<option value="77" >Kishanganj</option>
<option value="78" >Lakhisarai</option>
<option value="79" >Madhepura</option>
<option value="80" >Madhubani</option>
<option value="81" >Munger</option>
<option value="82" >Muzaffarpur</option>
<option value="83" >Nalanda</option>
<option value="84" >Nawada</option>
<option value="85" >Patna</option>
<option value="86" >Purnia</option>
<option value="87" >Rohtas</option>
<option value="88" >Saharsa</option>
<option value="89" >Samastipur</option>
<option value="90" >Aarah</option>
<option value="91" >Sheikhpura</option>
<option value="92" >Sheohar</option>
<option value="93" >Sitamarhi</option>
<option value="94" >Siwan</option>
<option value="95" >Supaul</option>
<option value="96" >Vaishali</option>
<option value="97" >West Champara</option>
<option value="98" >Chandigarh</option>
<option value="99" >Bastar</option>
<option value="100" >Bijapur</option>
<option value="101" >Bilaspur</option>
<option value="102" >Dantewada</option>
<option value="103" >Dhamtari</option>
<option value="104" >Durg</option>
<option value="105" >Jashpur</option>
<option value="106" >Janjgir-Champa</option>
<option value="107" >Korba</option>
<option value="108" >Koriya</option>
<option value="109" >Kanker</option>
<option value="110" >Kabirdham (formerly Kawardha);</option>
<option value="111" >Mahasamund</option>
<option value="112" >Narayanpur</option>
<option value="113" >Raigarh</option>
<option value="114" >Rajnandgao</option>
<option value="115" >Raipur</option>
<option value="116" >Surajpur</option>
<option value="117" >Dadra and Nagar Haveli</option>
<option value="118" >Dama</option>
<option value="119" >Diu</option>
<option value="120" >Central Delhi</option>
<option value="121" >East Delhi</option>
<option value="122" >New Delhi</option>
<option value="123" >North Delhi</option>
<option value="124" >North East Delhi</option>
<option value="125" >North West Delhi</option>
<option value="126" >South Delhi</option>
<option value="127" >South West Delhi</option>
<option value="128" >West Delhi</option>
<option value="129" >North Goa</option>
<option value="130" >South Goa</option>
<option value="131" >Ahmedabad</option>
<option value="132" >Amreli</option>
<option value="133" >Anand</option>
<option value="134" >Aravalli</option>
<option value="135" >Banaskantha</option>
<option value="136" >Bharuch</option>
<option value="137" >Bhavnagar</option>
<option value="138" >Dahod</option>
<option value="139" >Dang</option>
<option value="140" >Gandhinagar</option>
<option value="141" >Jamnagar</option>
<option value="142" >Junagadh</option>
<option value="143" >Kutch</option>
<option value="144" >Kheda</option>
<option value="145" >Mehsana</option>
<option value="146" >Narmada</option>
<option value="147" >Navsari</option>
<option value="148" >Pata</option>
<option value="149" >Panchmahal</option>
<option value="150" >Porbandar</option>
<option value="151" >Rajkot</option>
<option value="152" >Sabarkantha</option>
<option value="153" >Surendranagar</option>
<option value="154" >Surat</option>
<option value="155" >Tapi</option>
<option value="156" >Vadodara</option>
<option value="157" >Valsad</option>
<option value="158" >Ambala</option>
<option value="159" >Bhiwani</option>
<option value="160" >Ayodhya</option>
<option value="161" >Fatehabad</option>
<option value="162" >Gurgao</option>
<option value="163" >Hissar</option>
<option value="164" >Jhajjar</option>
<option value="165" >Jind</option>
<option value="166" >Karnal</option>
<option value="167" >Kaithal</option>
<option value="168" >Kurukshetra</option>
<option value="169" >Mahendragarh</option>
<option value="170" >Mewat</option>
<option value="171" >Palwal</option>
<option value="172" >Panchkula</option>
<option value="173" >Panipat</option>
<option value="174" >Rewari</option>
<option value="175" >Rohtak</option>
<option value="176" >Sirsa</option>
<option value="177" >Sonipat</option>
<option value="178" >Yamuna Nagar</option>
<option value="179" >Bilaspur</option>
<option value="180" >Chamba</option>
<option value="181" >Hamirpur</option>
<option value="182" >Kangra</option>
<option value="183" >Kinnaur</option>
<option value="184" >Kullu</option>
<option value="185" >Lahaul and Spiti</option>
<option value="186" >Mandi</option>
<option value="187" >Shimla</option>
<option value="188" >Sirmaur</option>
<option value="189" >Sola</option>
<option value="190" >Una</option>
<option value="191" >Anantnag</option>
<option value="192" >Badgam</option>
<option value="193" >Bandipora</option>
<option value="194" >Baramulla</option>
<option value="195" >Doda</option>
<option value="196" >Ganderbal</option>
<option value="197" >Jammu</option>
<option value="198" >Kargil</option>
<option value="199" >Kathua</option>
<option value="200" >Kishtwar</option>
<option value="202" >Kupwara</option>
<option value="203" >Kulgam</option>
<option value="204" >Leh</option>
<option value="205" >Poonch</option>
<option value="206" >Pulwama</option>
<option value="207" >Rajouri</option>
<option value="208" >Ramba</option>
<option value="209" >Reasi</option>
<option value="210" >Samba</option>
<option value="211" >Shopia</option>
<option value="212" >Srinagar</option>
<option value="213" >Udhampur</option>
<option value="214" >Bokaro</option>
<option value="215" >Chatra</option>
<option value="216" >Deoghar</option>
<option value="217" >Dhanbad</option>
<option value="218" >Dumka</option>
<option value="219" >East Singhbhum</option>
<option value="220" >Garhwa</option>
<option value="221" >Giridih</option>
<option value="222" >Godda</option>
<option value="223" >Gumla</option>
<option value="224" >Hazaribag</option>
<option value="225" >Jamtara</option>
<option value="226" >Khunti</option>
<option value="227" >Koderma</option>
<option value="228" >Latehar</option>
<option value="229" >Lohardaga</option>
<option value="230" >Pakur</option>
<option value="231" >Palamu</option>
<option value="232" >Ramgarh</option>
<option value="233" >Ranchi</option>
<option value="234" >Sahibganj</option>
<option value="235" >Seraikela Kharsawa</option>
<option value="236" >Simdega</option>
<option value="237" >West Singhbhum</option>
<option value="238" >Bagalkot</option>
<option value="239" >Bangalore Rural</option>
<option value="240" >Bangalore Urba</option>
<option value="241" >Belgaum</option>
<option value="242" >Bellary</option>
<option value="243" >Bidar</option>
<option value="244" >Bijapur</option>
<option value="245" >Chamarajnagar</option>
<option value="246" >Chikkamagaluru</option>
<option value="247" >Chikkaballapur</option>
<option value="248" >Chitradurga</option>
<option value="249" >Davanagere</option>
<option value="250" >Dharwad</option>
<option value="251" >Dakshina Kannada</option>
<option value="252" >Gadag</option>
<option value="253" >Gulbarga</option>
<option value="254" >Hassa</option>
<option value="255" >Haveri</option>
<option value="256" >Kodagu</option>
<option value="257" >Kolar</option>
<option value="258" >Koppal</option>
<option value="259" >Mandya</option>
<option value="260" >Mysore</option>
<option value="261" >Raichur</option>
<option value="262" >Shimoga</option>
<option value="263" >Tumkur</option>
<option value="264" >Udupi</option>
<option value="265" >Uttara Kannada</option>
<option value="266" >Ramanagara</option>
<option value="267" >Yadgir</option>
<option value="268" >Alappuzha</option>
<option value="269" >Ernakulam</option>
<option value="270" >Idukki</option>
<option value="271" >Kannur</option>
<option value="272" >Kasaragod</option>
<option value="273" >Kollam</option>
<option value="274" >Kottayam</option>
<option value="275" >Kozhikode</option>
<option value="276" >Malappuram</option>
<option value="277" >Palakkad</option>
<option value="278" >Pathanamthitta</option>
<option value="279" >Thrissur</option>
<option value="280" >Thiruvananthapuram</option>
<option value="281" >Wayanad</option>
<option value="282" >Lakshadweep</option>
<option value="283" >Agar</option>
<option value="284" >Alirajpur</option>
<option value="285" >Anuppur</option>
<option value="286" >Ashok Nagar</option>
<option value="287" >Balaghat</option>
<option value="288" >Barwani</option>
<option value="289" >Betul</option>
<option value="290" >Bhind</option>
<option value="291" >Bhopal</option>
<option value="292" >Burhanpur</option>
<option value="293" >Chhatarpur</option>
<option value="294" >Chhindwara</option>
<option value="295" >Damoh</option>
<option value="296" >Datia</option>
<option value="297" >Dewas</option>
<option value="298" >Dhar</option>
<option value="299" >Dindori</option>
<option value="300" >Guna</option>
<option value="301" >Gwalior</option>
<option value="302" >Harda</option>
<option value="303" >Hoshangabad</option>
<option value="304" >Indore</option>
<option value="305" >Jabalpur</option>
<option value="306" >Jhabua</option>
<option value="307" >Katni</option>
<option value="308" >Khandwa (East Nimar);</option>
<option value="309" >Khargone (West Nimar);</option>
<option value="310" >Mandla</option>
<option value="311" >Mandsaur</option>
<option value="312" >Morena</option>
<option value="313" >Narsinghpur</option>
<option value="314" >Neemuch</option>
<option value="315" >Panna</option>
<option value="316" >Raise</option>
<option value="317" >Rajgarh</option>
<option value="318" >Ratlam</option>
<option value="319" >Rewa</option>
<option value="320" >Sagar</option>
<option value="321" >Satna</option>
<option value="322" >Sehore</option>
<option value="323" >Seoni</option>
<option value="324" >Shahdol</option>
<option value="325" >Shajapur</option>
<option value="326" >Sheopur</option>
<option value="327" >Shivpuri</option>
<option value="328" >Sidhi</option>
<option value="329" >Singrauli</option>
<option value="330" >Tikamgarh</option>
<option value="331" >Ujjai</option>
<option value="332" >Umaria</option>
<option value="333" >Vidisha</option>
<option value="334" >Ahmednagar</option>
<option value="335" >Akola</option>
<option value="336" >Amravati</option>
<option value="337" >Aurangabad</option>
<option value="338" >Beed</option>
<option value="339" >Bhandara</option>
<option value="340" >Buldhana</option>
<option value="341" >Chandrapur</option>
<option value="342" >Dhule</option>
<option value="343" >Gadchiroli</option>
<option value="344" >Gondia</option>
<option value="345" >Hingoli</option>
<option value="346" >Jalgao</option>
<option value="347" >Jalna</option>
<option value="348" >Kolhapur</option>
<option value="349" >Latur</option>
<option value="350" >Mumbai City</option>
<option value="351" >Mumbai suburba</option>
<option value="352" >Nanded</option>
<option value="353" >Nandurbar</option>
<option value="354" >Nagpur</option>
<option value="355" >Nashik</option>
<option value="356" >Osmanabad</option>
<option value="357" >Parbhani</option>
<option value="358" >Pune</option>
<option value="359" >Raigad</option>
<option value="360" >Ratnagiri</option>
<option value="361" >Sangli</option>
<option value="362" >Satara</option>
<option value="363" >Sindhudurg</option>
<option value="364" >Solapur</option>
<option value="365" >Thane</option>
<option value="366" >Wardha</option>
<option value="367" >Washim</option>
<option value="368" >Yavatmal</option>
<option value="369" >Bishnupur</option>
<option value="370" >Churachandpur</option>
<option value="371" >Chandel</option>
<option value="372" >Imphal East</option>
<option value="373" >Senapati</option>
<option value="374" >Tamenglong</option>
<option value="375" >Thoubal</option>
<option value="376" >Ukhrul</option>
<option value="377" >Imphal West</option>
<option value="378" >East Garo Hills</option>
<option value="379" >East Khasi Hills</option>
<option value="380" >Jaintia Hills</option>
<option value="381" >Ri Bhoi</option>
<option value="382" >South Garo Hills</option>
<option value="383" >West Garo Hills</option>
<option value="384" >West Khasi Hills</option>
<option value="385" >Aizawl</option>
<option value="386" >Champhai</option>
<option value="387" >Kolasib</option>
<option value="388" >Lawngtlai</option>
<option value="389" >Lunglei</option>
<option value="390" >Mamit</option>
<option value="391" >Saiha</option>
<option value="392" >Serchhip</option>
<option value="393" >Dimapur</option>
<option value="394" >Kiphire</option>
<option value="395" >Kohima</option>
<option value="396" >Longleng</option>
<option value="397" >Mokokchung</option>
<option value="398" >Mo</option>
<option value="399" >Pere</option>
<option value="400" >Phek</option>
<option value="401" >Tuensang</option>
<option value="402" >Wokha</option>
<option value="403" >Zunheboto</option>
<option value="404" >Angul</option>
<option value="405" >Boudh (Bauda);</option>
<option value="406" >Bhadrak</option>
<option value="407" >Balangir</option>
<option value="408" >Bargarh (Baragarh);</option>
<option value="409" >Balasore</option>
<option value="410" >Cuttack</option>
<option value="411" >Debagarh (Deogarh);</option>
<option value="412" >Dhenkanal</option>
<option value="413" >Ganjam</option>
<option value="414" >Gajapati</option>
<option value="415" >Jharsuguda</option>
<option value="416" >Jajpur</option>
<option value="417" >Jagatsinghpur</option>
<option value="418" >Khordha</option>
<option value="419" >Kendujhar (Keonjhar);</option>
<option value="420" >Kalahandi</option>
<option value="421" >Kandhamal</option>
<option value="422" >Koraput</option>
<option value="423" >Kendrapara</option>
<option value="424" >Malkangiri</option>
<option value="425" >Mayurbhanj</option>
<option value="426" >Nabarangpur</option>
<option value="427" >Nuapada</option>
<option value="428" >Nayagarh</option>
<option value="429" >Puri</option>
<option value="430" >Rayagada</option>
<option value="431" >Sambalpur</option>
<option value="432" >Subarnapur (Sonepur);</option>
<option value="433" >Sundergarh</option>
<option value="434" >Karaikal</option>
<option value="435" >Mahe</option>
<option value="436" >Pondicherry</option>
<option value="437" >Yanam</option>
<option value="438" >Amritsar</option>
<option value="439" >Barnala</option>
<option value="440" >Bathinda</option>
<option value="441" >Firozpur</option>
<option value="442" >Faridkot</option>
<option value="443" >Fatehgarh Sahib</option>
<option value="444" >Fazilka</option>
<option value="445" >Gurdaspur</option>
<option value="446" >Hoshiarpur</option>
<option value="447" >Jalandhar</option>
<option value="448" >Kapurthala</option>
<option value="449" >Ludhiana</option>
<option value="450" >Mansa</option>
<option value="451" >Moga</option>
<option value="452" >Sri Muktsar Sahib</option>
<option value="453" >Pathankot</option>
<option value="454" >Patiala</option>
<option value="455" >Rupnagar</option>
<option value="456" >Ajitgarh (Mohali);</option>
<option value="457" >Sangrur</option>
<option value="458" >Shahid Bhagat Singh Nagar</option>
<option value="459" >Tarn Tara</option>
<option value="460" >Ajmer</option>
<option value="461" >Alwar</option>
<option value="462" >Bikaner</option>
<option value="463" >Barmer</option>
<option value="464" >Banswara</option>
<option value="465" >Bharatpur</option>
<option value="466" >Bara</option>
<option value="467" >Bundi</option>
<option value="468" >Bhilwara</option>
<option value="469" >Churu</option>
<option value="470" >Chittorgarh</option>
<option value="471" >Dausa</option>
<option value="472" >Dholpur</option>
<option value="473" >Dungapur</option>
<option value="474" >Ganganagar</option>
<option value="475" >Hanumangarh</option>
<option value="476" >Jhunjhunu</option>
<option value="477" >Jalore</option>
<option value="478" >Jodhpur</option>
<option value="479" >Jaipur</option>
<option value="480" >Jaisalmer</option>
<option value="481" >Jhalawar</option>
<option value="482" >Karauli</option>
<option value="483" >Kota</option>
<option value="484" >Nagaur</option>
<option value="485" >Pali</option>
<option value="486" >Pratapgarh</option>
<option value="487" >Rajsamand</option>
<option value="488" >Sikar</option>
<option value="489" >Sawai Madhopur</option>
<option value="490" >Sirohi</option>
<option value="491" >Tonk</option>
<option value="492" >Udaipur</option>
<option value="493" >East Sikkim</option>
<option value="494" >North Sikkim</option>
<option value="495" >South Sikkim</option>
<option value="496" >West Sikkim</option>
<option value="497" >Ariyalur</option>
<option value="498" >Chennai</option>
<option value="499" >Coimbatore</option>
<option value="500" >Cuddalore</option>
<option value="501" >Dharmapuri</option>
<option value="502" >Dindigul</option>
<option value="503" >Erode</option>
<option value="504" >Kanchipuram</option>
<option value="505" >Kanyakumari</option>
<option value="506" >Karur</option>
<option value="507" >Krishnagiri</option>
<option value="508" >Madurai</option>
<option value="509" >Nagapattinam</option>
<option value="510" >Nilgiris</option>
<option value="511" >Namakkal</option>
<option value="512" >Perambalur</option>
<option value="513" >Pudukkottai</option>
<option value="514" >Ramanathapuram</option>
<option value="515" >Salem</option>
<option value="516" >Sivaganga</option>
<option value="517" >Tirupur</option>
<option value="518" >Tiruchirappalli</option>
<option value="519" >Theni</option>
<option value="520" >Tirunelveli</option>
<option value="521" >Thanjavur</option>
<option value="522" >Thoothukudi</option>
<option value="523" >Tiruvallur</option>
<option value="524" >Tiruvarur</option>
<option value="525" >Tiruvannamalai</option>
<option value="526" >Vellore</option>
<option value="527" >Viluppuram</option>
<option value="528" >Virudhunagar</option>
<option value="529" >Adilabad</option>
<option value="530" >Hyderabad</option>
<option value="531" >Karimnagar</option>
<option value="532" >Khammam</option>
<option value="533" >Mahbubnagar</option>
<option value="534" >Medak</option>
<option value="535" >Nalgonda</option>
<option value="536" >Nizamabad</option>
<option value="537" >Ranga Reddy</option>
<option value="538" >Warangal</option>
<option value="539" >Dhalai</option>
<option value="540" >North Tripura</option>
<option value="541" >South Tripura</option>
<option value="542" >Khowai</option>
<option value="543" >West Tripura</option>
<option value="544" >Agra</option>
<option value="545" >Aligarh</option>
<option value="546" >Prayagraj</option>
<option value="547" >Ambedkar Nagar</option>
<option value="548" >Auraiya</option>
<option value="549" >Azamgarh</option>
<option value="550" >Bagpat</option>
<option value="551" >Bahraich</option>
<option value="552" >Ballia</option>
<option value="553" >Balrampur</option>
<option value="554" >Banda</option>
<option value="555" >Barabanki</option>
<option value="556" >Bareilly</option>
<option value="557" >Basti</option>
<option value="558" >Bijnor</option>
<option value="559" >Budau</option>
<option value="560" >Bulandshahr</option>
<option value="561" >Chandauli</option>
<option value="562" >Amethi (Chhatrapati Shahuji Maharaj Nagar)</option>
<option value="563" >Chitrakoot</option>
<option value="564" >Deoria</option>
<option value="565" >Etah</option>
<option value="566" >Etawah</option>
<option value="567" >Faizabad</option>
<option value="568" >Farrukhabad</option>
<option value="569" >Fatehpur</option>
<option value="570" >Firozabad</option>
<option value="571" >Gautam Buddh Nagar</option>
<option value="572" >Ghaziabad</option>
<option value="573" >Ghazipur</option>
<option value="574" >Gonda</option>
<option value="575" >Gorakhpur</option>
<option value="576" >Hamirpur</option>
<option value="577" >Hardoi</option>
<option value="578" >Hathras (Mahamaya Nagar);</option>
<option value="579" >Jalau</option>
<option value="580" >Jaunpur</option>
<option value="581" >Jhansi</option>
<option value="582" >Jyotiba Phule Nagar</option>
<option value="583" >Kannauj</option>
<option value="584" >Kanpur Dehat (Ramabai Nagar);</option>
<option value="585" >Kanpur Nagar</option>
<option value="586" >Kanshi Ram Nagar</option>
<option value="587" >Kaushambi</option>
<option value="588" >Kushinagar</option>
<option value="589" >Lakhimpur Kheri</option>
<option value="590" >Lalitpur</option>
<option value="591" >Lucknow</option>
<option value="592" >Maharajganj</option>
<option value="593" >Mahoba</option>
<option value="594" >Mainpuri</option>
<option value="595" >Mathura</option>
<option value="596" >Mau</option>
<option value="597" >Meerut</option>
<option value="598" >Mirzapur</option>
<option value="599" >Moradabad</option>
<option value="600" >Muzaffarnagar</option>
<option value="601" >Panchsheel Nagar (Hapur);</option>
<option value="602" >Pilibhit</option>
<option value="603" >Pratapgarh</option>
<option value="604" >Raebareli</option>
<option value="605" >Rampur</option>
<option value="606" >Saharanpur</option>
<option value="607" >Sambhal(Bheem Nagar);</option>
<option value="608" >Sant Kabir Nagar</option>
<option value="609" >Sant Ravidas Nagar</option>
<option value="610" >Shahjahanpur</option>
<option value="611" >Shamli</option>
<option value="612" >Shravasti</option>
<option value="613" >Siddharthnagar</option>
<option value="614" >Sitapur</option>
<option value="615" >Sonbhadra</option>
<option value="616" >Sultanpur</option>
<option value="617" >Unnao</option>
<option value="618" >Varanasi</option>
<option value="619" >Almora</option>
<option value="620" >Bageshwar</option>
<option value="621" >Chamoli</option>
<option value="622" >Champawat</option>
<option value="623" >Dehradu</option>
<option value="624" >Haridwar</option>
<option value="625" >Nainital</option>
<option value="626" >Pauri Garhwal</option>
<option value="627" >Pithoragarh</option>
<option value="628" >Rudraprayag</option>
<option value="629" >Tehri Garhwal</option>
<option value="630" >Udham Singh Nagar</option>
<option value="631" >Uttarkashi</option>
<option value="632" >Bankura</option>
<option value="633" >Bardhama</option>
<option value="634" >Birbhum</option>
<option value="635" >Cooch Behar</option>
<option value="636" >Dakshin Dinajpur</option>
<option value="637" >Darjeeling</option>
<option value="638" >Hooghly</option>
<option value="639" >Howrah</option>
<option value="640" >Jalpaiguri</option>
<option value="641" >Kolkata</option>
<option value="642" >Maldah</option>
<option value="643" >Murshidabad</option>
<option value="644" >Nadia</option>
<option value="645" >North 24 Parganas</option>
<option value="646" >Paschim Medinipur</option>
<option value="647" >Purba Medinipur</option>
<option value="648" >Purulia</option>
<option value="649" >South 24 Parganas</option>
<option value="650" >Uttar Dinajpur</option>
</select> </div></div>

<div class="col-md-6"><strong style="color:#003366;">Pincode </strong>
<input name="pincode" maxlength="6" type="text" class="form-control">
</div>

</div>
                                        

<div class="col-md-12"><strong style="color:#00CC00; font-size:18px;">Verification</strong></div>
<div class="row">
<div class="col-md-4">Enter Verification code</div>
<div class="col-md-4"><input name="vercode" type="text" id="TextBoxRegCode" class="form-control" required>
<span class="red" style="color:red;"> </span></div>
<div class="col-md-4"><img src="captcha.php" style="padding:5px;"></div>
</div> 


<div class="row">
<div class="col-md-12"><br/><br/>
<center><button type="submit" class="btn" name="submit" style="color: #ffffff;
    background-color: #CC0000;">Register Me</button></center></div>
</div>

</form>

                       
                </div>
                </div>
               
            </div>
        </div>
    </section>


<footer class="main-footer">
        <!--Footer Upper-->
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-lg-4 col-sm-6 col-xs-12">
                        <div class="footer-widget about-widget">
                            <div class="sec-title-three">
                                <h2>CONTACT US</h2>
                            </div>
                            <div class="text">Gokulshree School Of Management And Technology Private Limited,  Shrawasti -Uttar Pradesh -271831</div>
                            <ul class="about-contact-info">
                                <li><span class="icon flaticon-technology"></span> +91-9628281020</li>
                                <li><span class="icon fa fa-envelope-o"></span> info@gokulshreeschool.com</li>
								<!--<li><span><img src="images/icons/sms.png" alt=""></span> <strong>SMS RUBIX to 8506060000</strong></li>-->
                            </ul>
                        </div>
                        <center>
                        <a href="app-release.apk"><img src="images/applogo.png" style="width:70%;"></a>
                        </center>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget info-links">
                            <div class="sec-title-three">
                                <h2>Quick LINKS</h2>
                            </div>
                            <div class="links-outer">
                                <div class="row clearfix">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="index.php"><span class="fa fa-arrow-right"></span>Home</a></li>
                                            <li><a href="#"><span class="fa fa-arrow-right"></span>About Us</a></li>
                                            <li><a href="photos.php"><span class="fa fa-arrow-right"></span>Photos</a></li>
											<li><a href="videos.php"><span class="fa fa-arrow-right"></span>Videos</a></li>
                                            
                                            <li><a href="payment.php"><span class="fa fa-arrow-right"></span>Make Payment</a></li>
                                            
                                            
                                            
                                            <li><a href="contact-us.php"><span class="fa fa-arrow-right"></span>Contact Us</a></li>
                                            
                                            
											
                                        </ul>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="registration.php"><span class="fa fa-arrow-right"></span>Online Registration</a></li>
                                            <li><a href="verification.php"><span class="fa fa-arrow-right"></span>Student Verification</a></li>
                                        
                                        
                                            <li><a href="login.php"><span class="fa fa-arrow-right"></span>Student Login</a></li>
                                            
                                        <li><a href="download-admitcard.php"><span class="fa fa-arrow-right"></span>Admit Card</a></li>
                                         <li><a href="downloads.php"><span class="fa fa-arrow-right"></span>Downloads</a></li>
                                       <li><a href="result.php"><span class="fa fa-arrow-right"></span>Result</a></li>     
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget">
                            <div class="newsletter-form">
                                <div class="sec-title-three">
                                    <h2>SUBSCRIBE OUR NEWSLETTER</h2>
                                </div>
								                                <form method="post">
                                    <div class="row clearfix">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="name" value="" placeholder="Your Name" required>
                                            </div>
                                        </div>
										<div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="contact" value="" placeholder="Your Mobile No" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Your Email" >
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group button-group">
                                                <button type="submit" name="submit" class="btn-style-two theme-btn">SUBSCRIBE</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Footer Bottom-->
        <div class="auto-container">
            <div class="footer-bottom">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="copyright">Gokulshree School Of Management And Technology Private Limited &copy; 2026 &nbsp; | &nbsp; <a href="privacy-policy.php">Privacy Policy</a>
						
						</div>
                    </div>
                    <!--Column-->
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="social-icons-one pull-right">
                            <ul>
                                <li><a href="https://www.facebook.com/" target="_blank"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="https://twitter.com/" target="_blank"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="https://www.youtube.com/" target="_blank"><span class="fa fa-youtube"></span></a></li>
                                <li><a href="http://www.linkedin.com/" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/revolution.min.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox-media.js"></script>
<script type="text/javascript" src="js/owl.js"></script>
<script type="text/javascript" src="js/wow.js"></script>
<script type="text/javascript" src="js/script.js"></script>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+91-9628281020", // WhatsApp number
            company_logo_url: "//static.whatshelp.io/img/flag.png", // URL of company logo (png, jpg, gif)
            greeting_message: "Hello, how may we help you? Just send us a message now to get assistance.", // Text of greeting message
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
  
</body>
</html>