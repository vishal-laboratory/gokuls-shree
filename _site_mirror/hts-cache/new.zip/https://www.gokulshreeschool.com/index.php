<!DOCTYPE html>
<!-- saved from url=(0020)http://rubixtech.in/ -->
<html class="">
<head>
<title>Gokulshree School Of Management And Technology Private Limited</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="images/favicon.png">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<META HTTP-EQUIV="EXPIRES" CONTENT="0">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Gokulshree School Of Management And Technology Private Limited is one of the best Institute  in  Shrawasti -Uttar Pradesh -271831 where many of courses are available for students to join for making their career better. Apply Now!">
<meta name="keywords" content="Institutes in  Shrawasti -Uttar Pradesh -271831, Best Institute, Best College, Institute in  Shrawasti -Uttar Pradesh -271831">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/revolution-slider.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/responsive.css">

<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "Gokulshree School Of Management And Technology Private Limited",
  "url": "https://gokulshreeschool.com",
  "sameAs": [
    "https://www.facebook.com/",
    "https://twitter.com",
    "https://linkedin.com/",
    "https://plus.google.com/"
  ],
  "logo": "https://gokulshreeschool.com/images/logo.png",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "+91-9628281020",
    "contactType": "Customer Support :"
  }]
}
</script>
</head>

<body>
<div class="page-wrapper">
    <!-- Main Header / Header Style One-->
    <header class="main-header header-style-one">
        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container clearfix">
<!--Top Left-->
 <div class="column col-lg-8 col-md-8 col-sm-12 col-xs-12">
<center>             
<style>
.text-white {
    color: #fff !important;
}
.list-inline {
padding-left: 0;
margin-left: -5px;
list-style: none;
}
.list-inline>li {
    display: inline-block;
    margin-top: 5px;
	 margin-bottom: 5px;
    padding-right: 10px;
  margin-left:4px;
    font-weight: 800;
    background-color:#D9EEE1;
    border-radius: 10px;
}
.pl-10 {
    padding-left: 10px !important;
}
.text-black {
    color: #000 !important;
}
.list-inline>li:hover {
    background: #FFF4A3;
}
					</style>
			<ul class="list-inline sm-pull-none sm-text-center text-white mb-sm-20 mt-10" style="font-size:14px;padding-inline-start: 1px;">
      
			 <li class=" pl-10"><a href="contact-us.php" class="text-black"> Enquiry Here</a></li>
			 <li class=" pl-10"><a href="franchise.php" class="text-black">Franchise Details</a></li>
			  <li class=" pl-10"><a href="franchise-enquiry.php" class="text-black">Apply Franchise</a></li>
			  <li class=" pl-10"><a href="new" target="_blank" class="text-black">Franchise Login</a></li>
			   <li class=" pl-10"><a href="new" target="_blank" class="text-black"> Employee Login</a></li>
			  <li class="pl-10"><a href="login.php" class="text-black">Student Login</a></li>

			  
			 <!--<a href="new" class="text-white m-0 pl-10 mt-0" target="_blank"><span class="btn btn-theme-colored2 btn-xs">Login</span></a>-->  
			 
			 </ul>
             </center>  
				</div>
                <!--Top Right-->
				     <div class="column col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <center>
                    <ul class="links-nav clearfix" style="margin-top:10px;">
                       <li><a href="tell:+91-9628281020" target="_blank" style="color:#fff;"><span class=" fa fa-phone"></span>+91-9628281020</a></li>
                        <li><a href="https://www.facebook.com" target="_blank"><span class=" fa fa-facebook"></span></a></li>
                        <li><a href="https://twitter.com" target="_blank"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="https://www.youtube.com" target="_blank"><span class="fa fa-youtube"></span></a></li>
                        <li><a href="http://www.linkedin.com" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                    </ul>
              </center>
				</div>
            </div>
        </div>
        <!-- Header Top End -->
        <!--Header-Upper-->
        <div class="header-upper">
            <div class="auto-container">
                <div class="clearfix">
                    <div class="pull-left logo-outer">
                        <div class="logo">
						<a href="index.php">
						<img src="images/head.png" alt="Gokulshree School Of Management And Technology Private Limited logo" style="margin-top:5px; margin-bottom:5px;">
						</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
        <!--Header-Lower-->
        <div class="header-lower">
            <div class="auto-container">
                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                        <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                        <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                    <li><a href="verification.php">Student Verification</a></li>
					<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					<li><a href="placement.php">Placement</a></li>
						
						
			
                         </ul>
                                </li>
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                        
                             <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						
						
						
                         </ul>
                                </li>
								<li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                                </li>
								
								
                               
                                
                                <li><a href=""></a></li>
                            
                            	<li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
                             <li><a href="contact-us.php">Contact Us</a></li>
							  <li><a href="find_branch.php">Find Branch</a></li>
							  
						
						
                         </ul>
                                </li>
                            
                            
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                    <div class="btn-outer"><a href="franchise-enquiry.php" class="theme-btn quote-btn"><span class="fa fa-user"></span> Apply Franchise </a></div>
                </div>
            </div>
        </div>
        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.php" class="img-responsive"><img src="images/logo-small.png" alt="Gokulshree School Of Management And Technology Private Limited"></a>
                </div>
                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                      <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                     <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                                      
						<li><a href="verification.php">Student Verification</a></li>
						<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					
						<li><a href="placement.php">Placement</a></li>
                         </ul>
                                </li>
								
									<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                    <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						<li><a href="why_gbge.php">Why GBGE</a></li>
							
						
						
						
                         </ul>
                                </li>
								 <li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
                                 
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                             </li>
                               <li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
							<li><a href="contact-us.php">Contact Us</a></li>
							 <li><a href="find_branch.php">Find Branch</a></li>
							 </ul>
							 </li>
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                </div>
            </div>
        </div>
        <!--End Sticky Header-->
    </header>    <!--End Main Header -->
    <!--Main Slider-->
    <section class="main-slider">
        <div class="tp-banner-container">
            <div class="tp-banner">
                <ul>
				                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/1.jpg"  data-saveperformance="off"  
                        data-title="">
 				<img src="new/banner/ori/1637417879478.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                        <div class="tp-caption sft sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-100"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <h3 class="text-uppercase"></h3>
                        </div>
                        <div class="tp-caption sfl sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-50"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                           <!-- <h2>for our clients</h2>-->
                        </div>
                       <!-- <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="20"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"><a href="registration.php" class="theme-btn btn-style-one">Join Us</a></div>-->
                    </li>
					                     <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/1.jpg"  data-saveperformance="off"  
                        data-title="">
 				<img src="new/banner/ori/1637402291190.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                        <div class="tp-caption sft sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-100"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <h3 class="text-uppercase"></h3>
                        </div>
                        <div class="tp-caption sfl sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-50"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                           <!-- <h2>for our clients</h2>-->
                        </div>
                       <!-- <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="20"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"><a href="registration.php" class="theme-btn btn-style-one">Join Us</a></div>-->
                    </li>
					                     <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/1.jpg"  data-saveperformance="off"  
                        data-title="">
 				<img src="new/banner/ori/1638006065918.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                        <div class="tp-caption sft sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-100"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <h3 class="text-uppercase"></h3>
                        </div>
                        <div class="tp-caption sfl sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-50"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                           <!-- <h2>for our clients</h2>-->
                        </div>
                       <!-- <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="20"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"><a href="registration.php" class="theme-btn btn-style-one">Join Us</a></div>-->
                    </li>
					                     <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="images/1.jpg"  data-saveperformance="off"  
                        data-title="">
 				<img src="new/banner/ori/1632891587669.png"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                        <div class="tp-caption sft sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-100"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <h3 class="text-uppercase"></h3>
                        </div>
                        <div class="tp-caption sfl sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="-50"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                           <!-- <h2>for our clients</h2>-->
                        </div>
                       <!-- <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="left" data-hoffset="15"
                            data-y="center" data-voffset="20"
                            data-speed="1500"
                            data-start="0"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn"><a href="registration.php" class="theme-btn btn-style-one">Join Us</a></div>-->
                    </li>
					 					
                
                </ul>
                <div class="tp-bannertimer"></div>
            </div>
        </div>
    </section>    <!--About Section-->
    <section class="about-section">
        <div class="auto-container">
            
			<div class="row clearfix">
                <!--Column-->
				                <div class="column col-lg-7 col-md-8 col-sm-12">
                    <div class="about-content-box">
                        <div class="sec-title-one">
                            <h2>Welcome to Gokulshree School Of Management And Technology Pvt Ltd</h2>
                        </div>
                        <div class="text text-justify"><div>
<div style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><font face="Tahoma"><span style="font-size: 18.6667px;"><b>Gokulshree School Of Management And Technology Pvt Ltd is&nbsp; An Autonomous Body Registered under SR Act, 9(1)2012&nbsp;</b></span></font><span style="font-family: Tahoma;"><span style="font-size: 14pt;">has been registered under the Government of India, working in different fields of Programme &amp; Commercial Training sponsored by the Central Government by taking a vow to approach every class of Youth in the society. The Organization is also certified by ISO 9001: 2015. The Institute &amp; the Organization is also Registered under the&nbsp;</span></span><b style="font-family: Tahoma; font-size: 18.6667px;">&nbsp;An Autonomous Body Registered under SR Act, 9(1)2012</b><span style="font-family: Tahoma;"><span style="font-size: 14pt;">, Ministry of Micro, Small &amp; Medium Enterprises (MSME)<b>,&nbsp;</b><strong><span style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;"><span style="font-weight: normal;">NCS &ndash; National career Service</span></span></strong><strong><span style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">,</span></strong></span><strong><span style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">&nbsp;</span></strong><span style="font-size: 14pt;">Ministry of Labour &amp; Employment and Ministry of AYUSH and is accredited to conduct the various fields of technical programs sponsored by both the Govt.</span></span></div>
<div style="background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; margin: 0in 0in 6.25pt;"><b style="font-family: Tahoma; font-size: 18.6667px;">Gokulshree School Of Management And Technology Pvt Ltd is&nbsp;&nbsp;An Autonomous Body Registered under SR Act, 9(1)2012</b><font face="Tahoma"><span style="font-size: 18.6667px;"><b>&nbsp;</b></span></font><span style="font-family: Tahoma;"><span style="font-size: 14pt;">&nbsp;The main function of the society is to provide higher technical education in nominal charges for every group of society of Urban &amp; Rural areas all over India and get success in computer revolution which is the main dream of Indian Govt..</span></span></div>
</div>
<p></p>&nbsp;<a href="#" title="Read more about us">Read More..</a>
                        </div>
                    </div>
                </div>
                <!--Column-->
                <div class="column col-lg-5 col-md-4 col-sm-6 col-xs-12">
                    <div class="image-box">
                        <figure class="image">
                            <img src="new/product/category/1632892464871.jpg" alt="Gokulshree School Of Management And Technology Private Limited" title="Gokulshree School Of Management And Technology Private Limited" />
                        </figure>
                    </div>
                </div>
            </div>
   
   <div class="auto-container">
<div style="background-color:#04AA6D; color:#fff; padding:5px; border-radius:10px;">
    <style>
    p {
    position: relative;
    line-height: 0.8em;
}

p {
    margin: 0 0 0px;
    
}
</style>
<marquee onmouseover="this.stop();" onmouseout="this.start();"> <p>free government computer courses franchise* govt free computer education franchise* computer institute franchise* computer education franchise in village area* govt computer education franchise* computer center franchise* free franchise for computer center* govt schemes for computer education* ngo scheme for computer education* mputer training institute franchise* computer institute franchise absolutely free* free computer education scheme* govt project for computer education* computer training franchise* computer institute franchise* computer courses franchise* free computer center franchise* ngo franchise for computer education* government franchise for computer institute* most profitable computer education franchises* free computer education by ngo* franchise of educational institute* computer education institute franchise* study centre franchise* indian computer institute franchise form* computer education franchise in bangalore* central government computer courses franchise* government computer courses franchise* free govt computer courses* abacus franchise* free computer education* skill development institute franchise* computer education center registration* franchise for vocational courses* vocational training institute franchise* computer institute govt registration* youth computer training centre franchise* ngo computer education franchise* computer training centre affiliation* franchise opportunities in hyderabad* computer franchise* best computer institute franchise* franchise opportunities in pune* central government schemes for free computer education* government certified computer courses* govt approved computer courses* franchise opportunities in kerala* digital india franchise* franchise in hyderabad* government approved computer institute* online computer courses in india* govt recognised computer institute franchise* franchise opportunities in tamilnadu* education franchise opportunities* franchise opportunities in kolkata* free computer education project* govt computer course franchise* central government computer education scheme* education franchise in india* distance education franchise* govt affiliation for computer institute* computer training center business registration* institute of computer education* new business franchise* free computer education program* govt computer training center* franchise options in india* free franchise in india* central government project for computer education* top education franchises* computer saksharta mission* top franchise in india* central government free computer courses* free online computer courses in india* all india computer saksharta mission* government computer training institutes* franchise opportunities in andhra pradesh* government computer training scheme* govt approved computer institute* new computer institute registration* how to register computer training institute* registration of computer training institute* central govt scheme for computer education* computer franchise business* computer institute registration* franchise opportunities in gujarat* How to register computer center* emaxindia* sarvaindia* sarvaindia.com* emaxindia.in* gbindia* globalbrain* gbindia.in* computer center franchise in auraiya* how to register computer institute in auraiya*
</p></marquee> 
        </div>
</div>
        </div>
        
    </section>
    
    <!--Call To Action-->
    <section class="call-to-action" style="background-image:url(images/background/1.png);">
        <div class="auto-container">
            <div class="row">
                            <div class="col-sm-4">
                                
								<div class="panel panel-default">
<div style="background:#2b176e; color:#FFFFFF; padding:10px;">
<strong>Recently Join Centres</strong></a>
</div>
<div class="panel-body" style="background-color:#fffdf1;">
<div class="tab-content">
<div class="tab-pane fade in active" id="dlp2017" style="height:415px;">
<marquee behavior="scroll" direction="up" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();" style="height:400px;">
<ul class="lst">
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;">
<center>
<strong>Rajveer Singh Computer Training Centre </strong><br/>
<img class="alignnone size-full wp-image-4843" src="new/branch/172681387220.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Sanjay Kumar Chaudhary </strong><br/>
<strong>GOKUL003</strong><br/>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;">
<center>
<strong>Gokulshree School Of Management And Technology Private Limited</strong><br/>
<img class="alignnone size-full wp-image-4843" src="new/branch/1725693582906.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Ajeet</strong><br/>
<strong>GO110210825</strong><br/>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;">
<center>
<strong>Sanjeet  Jaiswal Computer Training Centre</strong><br/>
<img class="alignnone size-full wp-image-4843" src="new/branch/1726909814362.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Sanjeet Kumar Jaiswal</strong><br/>
<strong>GO10011002024</strong><br/>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;">
<center>
<strong>MAA SARASWATI COMPUTER CENTRE </strong><br/>
<img class="alignnone size-full wp-image-4843" src="new/branch/176157490789.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>AMAR DEV MISHRA </strong><br/>
<strong>GO05700251025</strong><br/>
</center>
</li>
<!------------  ------------>
</ul>
</marquee>
</div>
</div>
</div>
</div>

                               
                            </div>
                            <div class="col-sm-4">

<div class="panel panel-default">
<div style="background:#2b176e; color:#FFFFFF; padding:10px;">
<strong>Recently Join Student</strong></a>
</div>
<div class="panel-body" style="background-color:#fffdf1;">
<div class="tab-content">
<div class="tab-pane fade in active" id="dlp2017" style="height:415px;">
<marquee behavior="scroll" direction="up" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();" style="height:400px;">
<ul class="lst">
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1767421653554.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : Himanshi</strong><br/>
<strong>Course : Advance Diploma In Computer Application (ADCA) </strong><br/>
<strong>Branch : Sanjeet  Jaiswal Computer Training Centre</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/176741966614.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : Pragya Singh</strong><br/>
<strong>Course : Advance Diploma In Computer Application (ADCA) </strong><br/>
<strong>Branch : Sanjeet  Jaiswal Computer Training Centre</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1767089974997.jpeg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : Aman Bhargav</strong><br/>
<strong>Course : Advance Diploma In Computer Application (ADCA) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1767090187445.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : Om Prakash</strong><br/>
<strong>Course : Advance Diploma In Computer Application (ADCA) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1758548525245.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : Arjun</strong><br/>
<strong>Course : Diploma In Computer Application (DCA) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1755275572522.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : Seema Verma </strong><br/>
<strong>Course : Advance Diploma In Computer Application (ADCA) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1750656499146.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : SACHIN KUMAR</strong><br/>
<strong>Course : Certificate In Tally (CTALLY) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1750571198629.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : SATYAM TRIPATHI</strong><br/>
<strong>Course : Advance Diploma In Computer Application (ADCA) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="new/images/user/1746245179515.jpg" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : SUBHASH KUMAR</strong><br/>
<strong>Course : Advance Diploma In Computer Application (ADCA) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------     -------------->
<li style="border-bottom: 1px dotted #000;"><center>
<img class="alignnone size-full wp-image-4843" src="images/user.png" alt="" style="height:110px;width:120px;">
<br/>
<strong>Name : Tally Prime </strong><br/>
<strong>Course : Certificate In Tally (CTALLY) </strong><br/>
<strong>Branch : Gokulshree School Of Management And Technology Private Limited</strong>
</center>
</li>
<!------------  ------------>
</ul>
</marquee>
</div>
</div>
</div>
</div>
</div>
                            <div class="col-sm-4">
                               <style>
.panel {
    margin-bottom: 10px;
    background-color: #fff;
    border: 1px solid #eee;
}

b, strong {
    font-weight: 700;
}
.panel-body {
    padding: 5px;
	}
	.tab-content>.active {
    display: block;
}
.fade.in {
    opacity: 1;
}
ul.lst li:last-child {
    border-bottom: none;
}
ul.lst li {
    line-height: 20px;
    margin-bottom: 10px;
    list-style: none;
    border-bottom: 1px solid #000;
    padding-bottom: 10px;
}
</style>
<div class="panel panel-default">
<div style="background:#2b176e; color:#FFFFFF; padding:10px;">
<strong>News &amp; Events</strong></a>
</div>
<div class="panel-body" style="background-color:#fffdf1;">
<div class="tab-content">
<div class="tab-pane fade in active" id="dlp2017" style="height:415px;">
<marquee behavior="scroll" direction="up" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();" style="height:400px;">
<ul class="lst">
  
<!------------     -------------->
<li style="border-bottom: 1px solid #000;"><p></p>
<p><span style="font-family: &quot;Times New Roman&quot;;"> </span></p>
<p><span style="background-color: rgb(0, 0, 0);"><span style="color: rgb(255, 0, 255);"><strong>New Year Offer 2024</strong></span></span></p>
<p></p>
<h3></h3>
<h3><span style="background-color: rgb(255, 0, 0);"><span style="color: rgb(255, 255, 255);"><span style="font-family: Arial;"><strong>&nbsp;All Course 10% Discount&nbsp;</strong></span></span></span></h3></li>
  
<!------------     -------------->
<li style="border-bottom: 1px solid #000;"><h3></h3>
<p><span style="background-color: rgb(0, 0, 255);"> </span></p>
<h3><strong>FRANCHISE REQUIRED</strong></h3></li>
  
<!------------     -------------->
<li style="border-bottom: 1px solid #000;"><h3><span style="font-family: &quot;Comic Sans MS&quot;;"><span style="background-color: lime;"><span style="color: rgb(48, 48, 48); font-size: 14px;">FRANCHISE REQUIRED</span></span></span></h3>
<h3><span style="font-family: &quot;Comic Sans MS&quot;;"><span style="background-color: lime;">SEND FRANCHISE REQUEST All OVER INDIA LOCATIONS&nbsp;</span></span></h3></li>
  
<!------------     -------------->
<li style="border-bottom: 1px solid #000;"><h3><span style="background-color: rgb(0, 0, 255);"><span style="font-family: &quot;Comic Sans MS&quot;;">&nbsp;NEW ADMISSION OPEN &quot;ADCA, DCA, BASIC,ACCOUNTING&quot;&nbsp;</span></span></h3></li>
  
<!------------     -------------->
<li style="border-bottom: 1px solid #000;"><p></p>
<h3 style="color: red;"><span style="font-family: &quot;Comic Sans MS&quot;;"><span style="background-color: yellow;"><strong>CCC,BCC &amp; O LEVEL&nbsp; &quot;ADMISSION OPEN&quot;</strong> - GSMT&nbsp;</span></span><strong><br />
</strong></h3>
<p></p></li>
 
<!------------  ------------>
</ul>
</marquee>
</div>
</div>
</div>
</div>
</div>
                                
                            </div>
                            
                            
        </div>
    </section>    <!--Training Programs-->
        <!--Choose Us-->
    <!--Latest News Section-->
    <section class="latest-news">
<div class="auto-container">
<div style="background-color:#232434; color:#fff; padding:5px; border-radius:10px;">
    <style>
    p {
    position: relative;
    line-height: 0.8em;
}

p {
    margin: 0 0 0px;
    
}
</style>
<marquee onmouseover="this.stop();" onmouseout="this.start();"> <p>how to register a computer institute, new franchise, no franchise, how to register a computer institute, computer educational institute registration, how to start computer institute,how can I register my computer centre under Government of India, computer institute franchise,how to register computer training institute, business franchise, computer education franchise, computer education institute, udyog Aadhar registration without OTP, udyog Aadhar registration, online udyog Aadhar registration, how to online udyog Aadhar registration, MSMe registration ,how to online udyog Aadhar registration, computer education institute registration, how can I register my computer centre under Government of India, computer education franchise,howto Register vocational course, training franchise, institute franchise absolutely free, Education Franchise in India, Computer Institute Franchise Absolutely Free, Govt Affiliation For Computer Institute, how to register a yoga institute, SO certification for your training Center, vocational course franchise, Free Computer Center Franchise in India, ntt center registration, Yoga Franchise | Yoga Studio Franchise, no.1 Education Franchise in India, Best Education Franchise in India, how to get education franchise in india, Low Investment Franchise In India || Best Education Franchise Of India, Education Franchise Opportunities | Education Business Franchises in India, NTT, PTT, NPTT, Vocational Courses Centers Franchise in India, Nursery Teacher Training NTT Course Franchise Center Tag People also Search: Andhra Pradesh (Hyderabad) Arunachal Pradesh (Itanagar) Assam (Dispur) Bihar (Patna) Chhattisgarh (Raipur) Goa (Panaji) Gujarat (Gandhinagar) Haryana (Chandigarh) Himachal Pradesh (Shimla) Jammu & Kashmir (Srinagar-S*, Jammu-W*) Jharkhand (Ranchi) Karnataka (Bangalore) Kerala (Thiruvananthapuram) Madhya Pradesh (Bhopal) Maharashtra (Mumbai) Manipur (Imphal) Meghalaya (Shillong) Mizoram (Aizawl) Nagaland (Kohima) Odisha (Bhubaneshwar) Punjab (Chandigarh) Rajasthan (Jaipur) Sikkim (Gangtok) Tamil Nadu (Chennai) Telangana (Hyderabad) Tripura (Agartala) Uttarakhand (Dehradun) Uttar Pradesh (Lucknow) West Bengal (Kolkata).
 Tags: computer education affiliation, computer education franchise, computer education center registration,EDUCATION MAXIMUM PRIVATE LIMITED start a computer training institute, computer education centre franchise, computer training center registration, computer education centre, computer education affiliation franchise india, franchise for computer institute, education franchise services, computer training franchise india, computer education institute registration, institute of computer education, computer saksharta mission, computer institute registration process, skill development programme, skill development training program, vocational and skill development training center,Computer education franchise,agreement,absolutely free,csc government,village area,affiliation, education centre , best in software training and a certification training. digital marketing training in jaipur govt free computer education in Rajasthan Punjab Bihar,free computer education franchise in village area, Computer education franchise offer in Andhra Pradesh, absolutely, free,franchise, agreement,franchise, courses,csc computer education franchise,skill development training franchise,free computer education franchise in village area,education franchise proposal,free government computer courses franchise,free franchise for computer center,free franchise for computer institute in institute affiliation, become our computer franchisee, computer training govt project, free computer centre franchise, computer training govt schemes, ndlm scheme, pmkvy scheme Andaman and Nicobar, Arunachal Pradesh, Assam, Bihar, Chandigarh, Chhattisgarh, Dadra and Nagar Haveli,HR Daman and Diu, National Capital Territory of Delhi, Goa, Gujarat, Haryana, Himachal Pradesh, Jammu and Kashmir,Rajasthan, Sikkim, Tamil Nadu, Telangana, Tripura, Uttar Pradesh, Uttarakhand, West Bengal, Jharkhand, Karnataka, Kerala, Lakshadweep, Madhya Pradesh, Maharashtra, Manipur, Meghalaya, Mizoram, Nagaland, Odisha, Puducherry, Punjab, how to get pmkvy franchise,pmkvy franchise in west bengal,pmkvy franchise in odisha,pmkvy franchise in rajasthan,pmkvy franchise in bihar,pmkvy franchise in up,pmkvy franchise in uttar pradesh,ndlm franchise,ndlm center registration process,ndlm project,ndlm project details,ndlm registration online,ndlm center login,ndlm registration process,ndlm registration form,ndlm student,pmkvy franchise,kaushal vikas mission,kaushal vikas yojana,kaushal vikas yojana up,kaushal vikas yojna,upsdm org online registration,kaushal vikas mission up,up kaushal vikas mission,kaushal vikas,upsdm online registration,upsdm registration,kaushal vikas yojana registration,kaushal vikas yojana in up,up skill development mission,up kaushal vikas yojana,upsdm online form,upsdm online,upsdm org online form,kaushal vikas yojana online,kosal vikas yojana kaushal vikas yojna online registration,kaushal vikas yojna up,up kaushal vikas online form,kaushal vikas online form,kaushal vikas yojana online registration,kaushal vikas yojana online form,kaushal vikas prashikshan up,skill development mission,upsdm registration online,lakme training academy,vlcc institute of beauty & nutrition,orane institute of beauty & wellness,vlcc institute fees,vlcc professional makeup course fees vlcc beautician course fees,orane beauty academy,institutes for beautician course,Beauty, Cosmetology, Hair Dressing ,Makeup institute training colleges in Jaipur,Vocational Training Franchise,govt beauty parlour course in jaipur,beauty parlour course fees in jaipur,vlcc institute of beauty & nutrition jaipur rajasthan,beauty institute jaipur, rajasthan,beauty parlour institute in jaipur,beauty institute in jaipur,orane beauty academy, institute of beauty and wellness jaipur, rajasthan,beauty parlor course in jaipur ' Hyderabad 'Itanagar 'Dispur' Patna 'Raipur ' Panjim ' Gandhinagar ' Chandigarh ' Shimla ' Srinagar ' Jammu ' Ranchi ' Bangalore ' Thiruvananthapuram ' Bhopal ' Mumbai ' Imphal ' Aizawl ' Kohima 'Bhubaneswar ' Chandigarh ' Jaipur ' Gangtok ' Chennai ' Agartala ' Lucknow ' Dehradun ' Kolkata,free government computer courses franchise,csc computer education franchise,computer institute franchise,computer center franchise,free franchise for computer center,govt computer education franchise,free computer education franchisecomputer institute franchise free,computer education franchise,free computer education scheme,govt recognised computer institute, free computer center franchise,webel computer training centre franchise,govt free computer education,free franchise for computer institute,computer center franchise in west bengal,government franchise for computer institute,digital marketing training in jaipur,nct registration for computer institute,free franchise computer education india,itrc indore,computer education center registration,institute franchise proposal,govt computer institute in delhi,free computer franchise Free computer, institute, franchise,upsdm registration online,lakme training academy,vlcc institute of beauty & nutrition,orane institute of beauty & wellness,vlcc institute fees,vlcc professional makeup course fees,vlcc beautician course fees,orane beauty academy,institutes for beautician course,Beauty, Cosmetology, Hair Dressing ,Makeup institute absolutely, free,franchise, agreement,franchise, courses,csc computer education franchise,free computer education franchise in village area,education franchise proposal,free government computer courses franchise,free franchise for computer center,free franchise for computer institute in institute affiliation, become our computer franchisee, computer training govt project, free computer centre franchise, computer training govt schemes, ndlm scheme, pmkvy scheme,how to open a computer institute,computer courses in chandigarh, karnataka,Orissa,tamil nadu,Bihar,bharat kaushal,sarkari yojnaye,berojgar registration,kaushal vikas mission,kaushal vikas yojna lucknow,kaushal vikas bhatta in himachal pradesh,kaushal yojna,kaushal vikas kendra mp, Beauty Training Institutes in Jaipur,Vocational Training Franchise,Hyderabad,Itanagar,Dispur,Patna,Raipur,Panaji, Gandhinagar,Chandigarh, Shimla, Srinagar, Jammu, Ranchi,Bangalore,Thiruvananthapuram, Bhopal,Mumbai,Imphal, Shillong, Aizawl, Kohima, Bhubaneswar, Chandigarh, Jaipur, Gangtok, Chennai, Agartala,Lucknow, Dehradun ,Kolkata,skill development training franchise,soft skills training topics,soft skills training pptsoft skills training material pdf,soft skills training courses,soft skills training modules,soft skill training institutes,soft skills training in chennai,soft skills training bangalore,Computer Education Institute Free Franchise Proposal | Free Computer Education Franchise in Village area | Computer institute Franchise Absolutely free | Free government computer courses franchise | csc computer education franchise | digital marketing course in Jaipur | Govt free computer education franchise | computer center franchise | computer education franchise | Digital marketing institute in jaipur | govt free computer education | free franchise for computer center | free computer education franchise | govt computer education franchise | computer institute govt registration | digital marketing course fees in jaipur | free computer education | free computer education franchise in india | digital marketing training in jaipur | beauty parlour training centre in chandigarh | get pmkvy franchise | pmkvy franchise in west bengal | orissa | rajasthan | bihar | uttar pradesh | up | ndlm franchise | Cosmetics and Beauty Institute Franchise | Cosmetic Franchise Opportunities | Institute Cosmetic Franchises for Sale Opportunity | Beauty Academy Cosmetology Institute | Makeup Salon Spa Hair | institutes for beautician course,Beauty, Cosmetology, Hair Dressing ,Makeup institute training colleges in Jaipur | Beauty Training Institutes in Jaipur |Beauty Parlour Training Institutes in Jaipur | Vocational Training Franchise | govt beauty parlour course in jaipur | beauty parlour course fees in jaipur |beauty institute jaipur, rajasthan | beauty parlour institute in jaipur |beauty institute in jaipur | orane beauty academy, institute of beauty and wellness jaipur, rajasthan |beauty parlor course in jaipur | Hyderabad | Itanagar | Dispur | Patna | Raipur | Panaji | Gandhinagar | Chandigarh | Shimla | Srinagar | Jammu | Ranchi | Bangalore | Thiruvananthapuram | Bhopal | Mumbai | Imphal | Aizawl | Kohima | Bhubaneswar | Chandigarh | Jaipur | Gangtok | Chennai | Agartala | Lucknow | Dehradun | Kolkata | skill development training franchise | Andhra Pradesh | Arunachal Pradesh | Assam | Bihar | Chhattisgarh | Goa | Gujarat | Haryana | Himachal Pradesh |Jammu and Kashmir | Jharkhand | Karnataka | Kerala | Madhya Pradesh | Maharashtra | Manipur | Meghalaya | Mizoram | Nagaland | Odisha(Orissa) | Punjab | Rajasthan | Sikkim | Tamil Nadu | Tripura | Uttar Pradesh | Uttarakhand | West Bengal | basic computer course syllabusbasic computer courses list | basic computer courses for beginners | basic computer course fees | computer course list | basic computer courses book download | Air Hostess Training in Jaipur, Courses, Institutes,digital marketing training,digital training institute,digital marketing training in hyderabad,training digital,digital marketing training in bangalore,digital training,digital training academy,digital marketing training in chennai,digital marketing training in mumbai,digital marketing training london,digital marketing training bangalore,digital marketing training mumbai, Banking & Finance Courses Diploma in banking and finance, post graduate diploma in banking and finance, pg diploma in banking and finance, diploma in finance and banking, diploma courses in banking and finance, diploma in banking and finance eligibility, diploma in international banking and finance Banking & Finance, school programs, trade school programs, technical school programs, free school programs, in school programs, school education programs, international school programs online high school courses, high school courses online, online courses high school, high school online courses online courses for high school, online courses for high school students,Skills Training India skill development training,skill training,training skills,training and development skills,training and skills development,skill development and training, communication skills training, skills training centre, training skill development, skills training and development,skill development training courses, skill courses, professional skills course, short courses skills development, skill training courses, writing skills course, course skills, research skills course, skills courses, Computer Education Franchise Opportunities in India, best computer franchise, franchise opportunities for computer education, best franchise for computer education, franchise for computer education, open your own registered computer institute, computer training franchise
</p>
</marquee> 
</div>
</div>
</section>
<section class="latest-news">
        <div class="auto-container">
            
            <div class="sec-title-two">
                <h2>Our Programmes</h2>
            </div>
            <div class="row clearfix">
                <!--Column-->
                <div class="column col-lg-12 col-md-12 col-sm-12">
                    <div class="row clearfix">
						<!-- start project --> 
							  
						<div class="news-block col-md-4 col-sm-4 col-xs-12">
                            <div class="inner-box wow fadeIn" data-wow-delay="300ms" data-wow-duration="1500ms">
                                <figure class="image-box">
                                    <img src="new/images/user/1637418798270.jpg" alt="Diploma Courses " style="height:250px;">
                                    <div class="overlay-box"><a href="courses.php?cid=TVE9PQ==" ><span class="flaticon-chain-links"></span></a></div>
                                </figure>
                                <div class="lower-content">
                                    <div class="outer-link" style="padding-left:0px;">
                                        <h3 style="text-align:center;"><a href="courses.php?cid=TVE9PQ=="> Diploma Courses </a></h3>
                                       <!-- <div class="meta"><a href="javascript:return(0);">Content Writing</a></div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
						 
						<div class="news-block col-md-4 col-sm-4 col-xs-12">
                            <div class="inner-box wow fadeIn" data-wow-delay="300ms" data-wow-duration="1500ms">
                                <figure class="image-box">
                                    <img src="new/images/user/1637422147864.jpg" alt="Vocational Courses" style="height:250px;">
                                    <div class="overlay-box"><a href="courses.php?cid=TkE9PQ==" ><span class="flaticon-chain-links"></span></a></div>
                                </figure>
                                <div class="lower-content">
                                    <div class="outer-link" style="padding-left:0px;">
                                        <h3 style="text-align:center;"><a href="courses.php?cid=TkE9PQ=="> Vocational Courses</a></h3>
                                       <!-- <div class="meta"><a href="javascript:return(0);">Content Writing</a></div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
						 
						<div class="news-block col-md-4 col-sm-4 col-xs-12">
                            <div class="inner-box wow fadeIn" data-wow-delay="300ms" data-wow-duration="1500ms">
                                <figure class="image-box">
                                    <img src="new/images/user/1637570052318.jpg" alt="YOGA Courses" style="height:250px;">
                                    <div class="overlay-box"><a href="courses.php?cid=TlE9PQ==" ><span class="flaticon-chain-links"></span></a></div>
                                </figure>
                                <div class="lower-content">
                                    <div class="outer-link" style="padding-left:0px;">
                                        <h3 style="text-align:center;"><a href="courses.php?cid=TlE9PQ=="> YOGA Courses</a></h3>
                                       <!-- <div class="meta"><a href="javascript:return(0);">Content Writing</a></div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
						 
						<div class="news-block col-md-4 col-sm-4 col-xs-12">
                            <div class="inner-box wow fadeIn" data-wow-delay="300ms" data-wow-duration="1500ms">
                                <figure class="image-box">
                                    <img src="new/images/user/1637572347355.jpg" alt="University Courses" style="height:250px;">
                                    <div class="overlay-box"><a href="courses.php?cid=T1E9PQ==" ><span class="flaticon-chain-links"></span></a></div>
                                </figure>
                                <div class="lower-content">
                                    <div class="outer-link" style="padding-left:0px;">
                                        <h3 style="text-align:center;"><a href="courses.php?cid=T1E9PQ=="> University Courses</a></h3>
                                       <!-- <div class="meta"><a href="javascript:return(0);">Content Writing</a></div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
												
						
						<!-- start project --> 
						
						
						
                    </div>
                </div>
                <!--Column-->
            </div>
            
            <div class="auto-container">
<div style="background-color:#7d4e92; color:#fff; padding:5px; border-radius:10px;">
    <style>
    p {
    position: relative;
    line-height: 0.8em;
}

p {
    margin: 0 0 0px;
    
}
</style>
<marquee onmouseover="this.stop();" onmouseout="this.start();">
<p>Computer Education Franchise In Mp * Maharashtra* Up* Rajashtan* Hariyana* * Computer Education Franchise Franchise In West Bengal* Orrisa* Odisha* Dia* Himachal* Himachal Pradesh* North Dia* South Dia* East Dia* All Over Dia* Guideline Computer Education Franchise Training Centre Guidence* Uttar Pradesh Up Haryana Maharshtra Rajasthan Himachal Pradesh Manipur Sikkim * Jammu Jammu And Kashmir Meghalaya Tamilnadu Jharkhand Mizoram Tripura Nagaland Uttarakhand Goa Orissa Mp Punjab West Bengal * Ahmedabad* Anand* Dewas* Bhopal* Computer Education Franchise Franchise In* – Dore * Ujja * Ashta * Dhar * Mhow * Pithampur * Maksi * Sarangpur * Shajapur * Sehdol * Kotma * Ganganagar * Jaipur * Delhi * Mumbai * Udaypur * Udaipur * Allahabad * Surat * Lakhimpur Kheri * Lakhimpur * Lucknow * Sagar * Rai Bareli * East Ahmedabad * Guntur * Pipriya * Betul* Chhatarpur * S Grauli * Sidhi* Satna* Madhopur* Banswara * Jalore * Kota * Nagpur * Pali * Jhalawar * Jhunjhunu * Jodhpur * Karauli * Jangir Champa * Kanker * Korba * Mahasamund * Raigarh * Rajnandgaon * Sarguja * Bilaspur * Raipur * Dadra * * Nagar * Haveli * Daman * And * Diu * North * Goa * South * Goa * Ahmedabad * East * Ahmedabad * West * Anand * Bharuch * Chhotaudepur * Dahod * Gandh Agar * Amreli * Bhavnagar * Jamnagar * Kheda * Mehsana * Navsari * Junagadh * Rajkot * Shahjahanpur * Akbarpur * Etah * Kairana * Bansgaon * Almora * Hardwar * Na Ital Udhams Gh * Nagar * Tehri * Garhwal * Tehri * Garhwal * Alipurduars * Arambagh * Asansol * Baharampur * Bangaon * Bankura * Barasat * Bardhaman * Purba * Bardhaman Durgapur * Barrackpur * Basirhat * Bishnupur * Coochbehar * Darjeel G * Diamond * Harbour * Dum * Dum * Ghatal * Hooghly * Howrah * Jadavpur * Jalpaiguri * Jangipur * Jaynagar * Kanthi * Kolkata * Daksh * Kolkata * Uttar * Krishnanagar * Maldaha * Daksh * Mathurapur * Med Ipur * Murshidabad * Nadia * Purulia * Raiganj * Ranaghat * Serampore * Tamluk * Uluberia * Balurghat * Bolpur * Jhargram * Maldaha * Uttar * Nilgiris * Pollachi * Ramanathapuram * Salem * Sivaganga * Sriperumbudur * Tenkasi * Thanjavur * Theni * Thoothukudi * Tiruchirappalli * Tirunelveli * Tiruppur * Tiruvallur * Tiruvannamalai * Vellore * Viluppuram * Virudhunagar * Cuddalore * Perambalur * Adilabad * Bhongir * Chelvella * Hyderabad * Karimnagar * Khammam * Mahabubabad * Mahabubnagar * Malkajgiri * Medak * Nalgonda * Nizamabad * Secunderabad * Warangal * Zaheerabad * Nagarkurnool * Peddapalle * Shivpuri * Guna * Mirzapur * Misrikh * Mohanlal Ganj * Moradabad * Naga * Pratapgarh * Raebareli * Robartsganj * Saharanpur * Sambhal * Sant * Kabir * Nagar * Fatehpur * Shrawasti * Sitapur * Sultanpur * Unnao * Varanasi * Azamgarh * Badaun * Bahraich * Bhadohi * Deoria * Fatehpur * Sikri * Firozabad * Kaiserganj * Kannauj * Kheri * Lalganj * Maharajganj * Muzaffarnagar * Phulpur * Pilibhit * Rampur * Salempur * Ghazipur * Hardoi * Kush Agar * Gaya * Gopalganj * Jahanabad * Jamui * Katihar * Khagaria * Madhubani * Maharajganj * Mujaffarpur * Munger * Nalanda * Nawada * Pataliputra * Patna * Sahib * Purvi * Champaran * Samastipur * Saran * Sarasam * Sitamarhi * Siwan * Valmiki * Nagar * Paschim * Champaran * Aurangabad * Banka * Begusarai * Hajipur * Jhanjharpur * Karakat * Kishanganj * Madhepura * Purnia * Sheohar * Vaishali * Buxar * Darbhanga * Supaul * Ujiarpur * Arrah * Bhagalpur * Chandigarh * Bastar * Durg * Sabarkantha * Surat * Vadodara * Kachchh * Banaskantha * Bardoli * Patan * Porbandar * Surendranagar * Panchmahal * Valsad * Bhiwani * Faridabad * Gurgaon * Hisar * Gwalior * D Dori * Tikam * Garh * Davanagere * Hassan * Mandya * Tumkur * Uttara * Kannada * Chamrajanagar * Alapuzha * Alathur * Att Gal * Ernakulam * Kannur * Kasaragod * Kollam * Kottayam * Kozhikode * Palakkad * Pathanamthitta * Ponnani * Thiruvananthapuram * Hamirpur * Kangra * Mandi * Shimla * Anantnag * Baramullah * Jammu * Ladakh * Sr Agar * Udhampur * Chatra * Giridih * Godda * Hazaribagh * Jamshedpur * Palamu * Rajmahal * Dumka * Khunti * Ranchi * Dhanbad * S Ghbhum * Kodarama * Lohardagga * Bagalkot * Bangalore * Central * Bangalore * North * Bangalore * Rural * Bangalore * South * Belgaum * Bellary * Bidar * Bijapur * Chikkballapur * Dharwad * Gulbarga * Haveri * Kolar * Koppal * Mysore * Raichur * Shimoga * Udupi * Chikkodi * Chitradurga * Daksh A * Kannada * Thrissur * Vadakara * Chalakudy * Idukki * Malappuram * Mavelikkara * Wayanad * Lakshadwep * Balaghat * Bhopal * Chh Dwara * Dhar * Guna * Gwalior * Hosangabad * Dore * Betul * Damoh * Khandwa * Khandwa * Khargone * Mandsaur * Morena * Ratlam * Rewa * Sagar * Satna * Jabalpur * Tikamgarh * Khajuraho * Vidisha * Bh D * Sidhi * Shahdol * Ujja * Dewas * Rajgarh * Mandla * Akola * Amrawati * Aurangabad * Beed * Bhandara Gondiya * Bhiwandi * Buldhana * Dhule * Ahmednagar * Gadchiroli * H Goli * Jalgaon * Jalna * Kalyan * Kolhapur * Latur * Maval * Mumbai North Central * Mumbai Nwest * Mumbai South Central * Nagpur * Nanded * Nandurbar * Nashik * North * Mumbai * Palghar * Parbhani * Pune * Raigad * Ramtek * Ratnagiri * Chandrapur * S.Mumbai * Sangli * Satara * Shirdi * Shirur * Solapur * Thane * Wardha * Yavatmal Washim * Baramati * Hatkanangle * Madha * Mumbai North East * Osmanabad * D Dori * Raver * Ner * Manipur * Outer * Manipur * Shillong * Tura * Mizoram * Nagaland * Chandni * Chowk * East * Delhi * N.Delhi * North * East * North * West * South * Delhi * West * Delhi * Arani * Chennai * Central * Chennai * North * Chennai * South * Chidambaram * Coimbatore * Dharmapuri * D Digul * Erode * Kallakurichi * Kancheepuram * Kanniyakumari * Karur * Krishnagiri * Madurai * Mayiladuthurai * Nagapatt Am * Namakkal * East * Tripura * W.Tripura * Agra * Aligarh * Allahabad * Ambedkar * Nagar * Amethi * Amroha * Aonla * Baghpat * Ballia * Barabanki * Bareilly * Basti * Bulandshahr * Chandauli * Dhaurahra * Domriyaganj * Etawah * Faizabad * Gautam * Buddha * Nagar * Ghaziabad * Banda * Ghosi * Gonda * Gorakhpur * Hamirpur * Bijnor * Hathrus * Jalaun * Jaunpur * Jhansi * Kanpur * Kaushambi * Farrukhabad * Lucknow * Machhli * Shahar * Ma Puri * Mathura * Meerut * Andaman * * Nicobar * Amalapuram * Anaka * Pally * Anantapur * Araku * Chittoor * Eluru * Guntur * H Dupur * Kadapa * Kak Ada * Machilipatnam * Narasaraopet * Nellore * Rajahmundry * Srikakulam * Tirupathi * Vijayawada * Visakhapatnam * Vizianagaram * Nandyal * Rajampet * Kurnool * Ongole * Narsapuram * Bapatla * * East * * West * Barpeta * Dhubri * Dibrugarh * Gauhati * Jorhat * Kaliabor * Lakhimpur * Mangaldoi * Nawgong * Silchar * Tezpur * Autonomous * District * Kokrajhar * Karimganj * Araria * Karnal * Kurukshetra * Rohtak * Sirsa * Sonipat * Ambala * Aska * Balasore * Berhampur * Bhadrak * Bhubaneswar * Bolangir * Cuttack * Dhenkanal * Jagats Ghpur * Pithampur * Sanwer * Ujja * Kalahandi * Kandhmal * Kendrapara * Mayurbhanj * Nabarangpur * Puri * Sambalpur * Sundargarh * Bargarh * Koraput * Keonjhar * Jajpur * Puducherry * Amritsar * Anandpur * Sahib * Bhat Da * Faridkot * Ferozpur * Gurdaspur * Jalandhar * Ludhiana * Patiala * Sangrur * Fatehgarh * Sahib * Hoshiarpur * Khadoor * Sahib * Ajmer * Alwar * Barmer * Bharatpur * Bhilwara * Bikaner * Chittorgarh * Churu Hawai * * Anjaw * Hawa * Ichanglang * Dibang Valley * An I * East Kameng * Seppa * East Siang * Kra Daadi * Jam * Kurung Kumey * Koloriang * Tezu * Longd G * Longd G * Subansiri * Ziro * Namsai * Namsai * Yupia * Papum Pare * Yupia * Siang * Pang Siang * Siang * Pang * Tawang * Khonsa * Baksa * Mushalpur * Barpeta * Bishwanath * Cachar * Dhemaji * Sonari * Kajalgaon * Dhubri * Dibrugarh * Dima Hasao * Haflong * Golaghat * Hojai * Dibrugarh * Dhubri* Goalpara * Golaghat * Hailakandi * Hojai * Jorhat * Kamrup * Am Gaon * Guwahati * Karbi Anglong * Diphu * Karimganj * Kokrajhar * North * Lakhimpur * Garamur * Majuli * Morigaon * Nagaon * Nalbari * Sibsagar * Sivasagar * Hats Gimari * Sivasagar * Sonitpur * Tezpur * T Sukia * Udalguri * Anglong[10] * Hamren * West Karbi * * Araria * Arwal * Aurangabad * Banka * Begusarai * Bhagalpur * Arrah * Buxar * Darbhanga * Bhojpur * East * Champaran * Motihari * Gaya * Gopalganj * Jamui * Kaimur * Bhabua * K Nalanda Hagaria * Katihar * Kishanganj * Lakhisarai * Madhepura * Madhubani * Munger * Muzaffarpur * Sharif * Patna * Rohtas * Sasaram * Sasaram * Saharsa * Samastipur * Nawada * Chhapra * Sheikhpura * Sheikhpura * Sitamarhi * Siwan * Supaul * Vaishali * Hajipur * Bettiah * Champaran * * Balod* Baloda Bazar * Balrampur * Jagdalpur * Bemetara * Bijapur * Bilaspur * Dantewada * Bastar * Dhamtari * Durg * Gariaband * Naila Janjgir * Jashpur * Kawardha * Kabirdham * In Kabirdham * (Formerly Kawardha)* Kanker * Kondagaon * Korba * Baikunthpur * Mahasamund * Mungeli * Narayanpur * Raigarh * Raipur * Rajnandgaon * Sukma * Surajpur * Surguja * Delhi* In New Delhi * Connaught * Place * North Delhi * Sadar Bazaar North East * Shahdara * Delhi * Shahdara * Saket * Defence * South East * Delhi * Defence * Colony * South West Delhi * Vas Ant V Ihar * West Delh * South West Delhi * GOA * North Goa * Panaji * Margao * COMPUTER EDUCATION FRANCHISE Franchise In South Goa * * Ahmedabad * Amreli * Anand * Modasa * Banaskantha * Palanpur * Bharuch * Bhavnagar * Botad * Chhota Udaipur * Dahod * Ahwa * Devbhoomi Dwarka * Khambhalia * Gandh Agar * Gir Somnath * Veraval * Jamnagar * Junagadh * Kheda * Nadiad * Kutch * Bhuj * Lunavada * Mahisagar * Mehsana * Rajpipla * Morbi * Navsari * Panchmahal * Godhra * Patan * Porbandar * COMPUTER EDUCATION FRANCHISE Franchise In Rajkot * Sabarkantha * Himatnagar * Surat * Surendranagar * Tapi * Vyara * Vadodara * Valsad * Narmada * Ambala * Bhiwani * Charkhi Dadri * Faridabad * Fatehabad * Gurgaon * Hissar * Jhajjar * J D * Panipat Kaithal * Karnal * Kurukshetra * Mahendragarh * Narnaul * Nuh * Mewat * Palwal * Panchkula * Rewari * Rohtak * Sirsa * Sonipat * Yamuna Nagar* Bilaspur * Chamba * Hamirpur * Kangra * Dharamshala * K Naur * Reckong Peo * Kullu * Lahaul And Spiti * Keylong * Mandi * Shimla * Sirmaur * Nahan * Una * Solan * Jammu And Kashmir * Anantnag * Bandipore * Baramulla * Badgam * Doda * Ganderbal * Jammu * Kargil * Kathua * Kishtwar * Kulgam * Kupwara * Leh * Poonch * Pulwama * Rajouri * Ramban * Reasi * Samba * Shopian * Shupiyan * Sr Agar * Udhampur * Bokaro * Chatra * Deoghar * Dhanbad * Dumka * Jamshedpur * Garhwa * Giridih * Godda * Gumla * Hazaribag * Jamtara Khunti * Koderma * Latehar * Lohardaga * Pakur * Palamu * Daltonganj * Ramgarh * Ranchi * Sahibganj * Neraikela * Kharsawan * Simdega * Chaibasa * West S Ghbhum * Bagalkot * Ballari * Belagavi * Bengaluru Rura * Bengaluru * Urban * Bidar * Chamarajanagar * Franchise In Chikkaballapur * Chikmagalur * Chitradurga * Mangaluru * Davangere * Dharwad * Gadag * Gadag-Betageri * Hassan * Haveri * Kalaburagi * Madikeri * Kodagu * Koppal* Kolar * Mandya * Mysuru * Raichur * Ramanagara * Shivamogga * Tumakuru * Karwar * Udupi * Vijayapura * Yadgir * Uttara Kannada * Karwar * Vijayapura * Yadgir * * Alappuzha * Ernakulam * Kakkanad * Pa Avu * Kannur * Kasaragod * Kollam * Kottayam * Idukki * Kozhikode * Malappuram * Palakkad * Pathanamthitta * Thrissur * Pathanamthitta * Thrissur * Wayanad * Kalpetta * Thiruvananthapuram * * Agar Malwa * Anuppur * Alirajpur * Agar * Ashok Nagar * Balaghat * Barwani * Betul * Bh D * Bhopal * Burhanpur * Chhatarpur * Chh Dwara * Damoh * Datia * Dewas * Dhar * D Dori * Harda * Hoshangabad * Dore * Jabalpur * Jhabua * Katni * Khandwa * Khandwa (East Nimar) * Khargone (West Nimar) * Khargone * Mandla * Mandsaur * Morena * Nars Ghpur * Neemuch * Panna * Raisen * Rajgarh * Rewa * Ratlam * Sagar * Satna * Sehore * Seoni * Shahdol * Shajapur * Sheopur * Shivpuri * Sidhi * Tikamgarh * Waidhan * Tikamgarh * Ujja * Umaria * Vidisha . Maharashtra * Ahmednagar * Akola * Amravati * Aurangabad * Beed * Bhandara * Buldhana * Chandrapur * Dhule * Gadchiroli * Gondia * H Goli * Jalgaon * Jalna * Kolhapur * Latur * Mumbai * Mumbai City * Latur * Suburban * Suburban * Bandra (East) * Nanded * Nandurbar * Nagpur * Nashik * Osmanabad * Palghar * Parbhani * Pune * Alibag * Raigad * Ratnagiri * Sangli * Satara * S Dhudurg * Oros * Solapur * Thane * Wardha * Washim * Yavatmal * Manipur * Bishnupur * Churachandpur * Chandel * Imphal East * Porompat * Senapati * Tamenglong * Thoubal * Ukhrul * Imphal West * Lamphelpat * Meghalaya * East Garo Hills * Williamnagar * East Khasi Hills * Shillong * Khleihriat * North Garo Hills * East Ja Tia Hills * Resubelpara * Ri Bhoi * Nongpoh * South Garo Hills * Baghmara * Ampati * South West Khasi Hills * Mawkyrwat * South West Garo Hills * West Ja Tia Hills * Jowai * West Garo Hills * Tura * West Khasi Hills* Nongsto * Mizoram * Aizawl * Champhai * Kolasib * Lawngtlai * Lunglei * Mamit * Saiha * Serchhip * Nagaland * Dimapur * Kiphire * Kohima * Longleng * Mokokchung * Mon * Peren * Phek * Tuensang * Wokha * Zunheboto * Gangtok * Odisha * Angul * Boudh * Bhadrak * Balangir * Bargarh * Balasore * Cuttack * Balasore * Cuttack * Debagarh * Dhenkanal * Chhatrapur * Ganjam * Gajapati * Paralakhemundi * Jharsuguda * Jajpur * Panikoili * Jagats Ghpur * Khordha * Kendujhar * Kmayurbhanjalahandi * Bhawanipatna * Kandhamal * Phulbani * Koraput * Kendrapara * Malkangiri * Baripada * Nabarangpur * Nuapada * Nayagarh * Puri * Rayagada * Sambalpur * Subarnapur * Sundargarh * Puducherry * Karaikal * Mahé * Yanam * Pondicherry * Punjab * Amritsar * Bath Da * Firozpur * Faridkot * Fatehgarh Sahib * Fazilka* Gurdaspur * Hoshiarpur * COMPUTER EDUCATION FRANCHISE Franchise In Barnala * Jalandhar * Kapurthala * Ludhiana * Mansa * Sri Muktsar Sahib * Pathankot * Patiala * Moga * Sri Muktsar Sahib * Pathankot * Patiala * Rupnagar * Sahibzada Ajit S Gh Nagar * Ajitgarh * Sangrur * Nawanshahr * Shahid Bhagat S Gh Nagar * Nawanshahr * Tarn Taran Sahib * Tarn Taran * Rajasthan * Ajmer * Alwar * Bikaner * Barmer * Bharatpur * Baran * Bundi * Bhilwara * Churu * Chittorgarh * Banswara * Dausa * Dholpur * Dungarpur * Ganganagar * Hanumangarh * Jhunjhunu * Jodhpur * Karauli * Jhalawar * Kota * Nagaur * Pratapgarh * Rajsamand * Sikar * Pali * Sawai Madhopur * Tonk * Udaipur * Sikkim * East Sikkim * Gangtok * Mangan * North Sikkim * South Sikkim * Namchi * West Sikkim * Geyz G * Tamil NADU * Ariyalur * Coimbatore* Chennai * Cuddalore * D Digul* Erode * Kanchipuram * Dharmapuri * Karur * Kanyakumari * Nagercoil * Krishnagiri * Nagapatt Am * Madurai * Nilgiris * Namakkal * Perambalur * Pudukkottai * Salem * Sivaganga * Udagamandalam (Ootacamund/Ooty * Tiruchirappalli * Tirunelveli * Theni * Thanjavur * Thoothukudi * Tiruvallur * Ramanathapuramv * Tirupur * Tiruvarur * Tiruvannaamalai * Vellore * Viluppuram Virudhunagar * Vellore * Viluppuram * Tripura * Dhalai * Ambassa * Gomati * Udaipur* Tripura * Khowai * North Tripura* Dharmanagar * Sepahijala * South Tripura * Bishramganj * Belonia * Unokoti * Kailashahar * Agartala * West Tripura * Telangana * Adilabad* Komaram Bheem Asifabad * Asifabad * Bhadradri Kothagudem * Kothagudem * Hyderabad * Jagtial* Jangaon * Jayashankar Bhupalpally * Bhupalpalle * Jogulamba Gadwal* Kamareddy * Karimnagar * Khammam* Mahabubabad * Mahbubnagar * Medak * Medchal* Mancherial * Malkajgiri * Nalgonda * Nagarkurnool * Nirmal * Nizamabad * Rajanna Sircilla * Peddapalli * Sircilla* Sangareddy * Siddipet * Suryapet * Vikarabad * Wanaparthy * Bhongiri Hyderabad * Ranga Reddy * Warangal (Urban) * Warangal (Rural) * Yadadri Bhuvanagiri * Uttar Pradesh * Agra* Aligarh* Allahabad* Ambedkar Nagar * Akbarpur * Gauriganj * Amroha * Auraiya * Amethi (Chhatrapati Shahuji Maharaj Nagar) Amroha (Jyotiba Phule Nagar) * Azamgarh * Bagpat* Bahraich * Ballia* Balrampur * Banda* Barabanki * Bareilly * Basti * Budaun * Chandauli * Bijnor * Chitrakoot* Deoria * Etah * Etawah * Faizabad * Farrukhabad* Fatehgarh * Fatehpur * Firozabad * Gautam Buddh Nagar * Noida * Ghaziabad * Ghazipur * Gonda * Orai* Jaunpur * Gorakhpu * Hamirpur* Hapur* Hardoi* Hathras (Mahamaya Nagar) * Jalaun * Jhansi * Hapur (Panchsheel Nagar) * Kannauj * Akbarpur (Mati)* Kanpur Nagar * Manjhanpur * Kanpur Dehat (Ramabai Nagar)* Ram Nagar) * Kasganj* Kaushambi * Padrauna* Kasganj (Kanshi * Lakhimpur Kheri * Kush Agar * Lalitpur* Lucknow * Maharajganj * Mahoba * Ma Puri * Mathura * Mau* Meerut* Mirzapur * Moradabad * Muzaffarnagar* Pilibhit* Raebareli * Pratapgarh * Rampur * Saharanpur * Sambhal (Bheem Nagar)* Sant Kabir Nagar * Khalilabad * Sant Ravidas Nagar* Gyanpur* Shahjahanpur * Shamli * Shravasti * Siddharthnagar * Navgarh* Sitapur* Sonbhadra * Robertsganj * Unnao * Varanasi * Sultanpur * Uttarakhand * Almora* Bageshwar* Chamoli* Gopeshwar * Champawat * Dehradun * Haridwar * Na Ital * Pauri Garhwal * Pauri * Pithoragarh * Rudraprayag * Tehri Garhwal * New Tehri * Udham S Gh Nagar * Rudrapur * Uttarkashi * West Bengal * Alipurduar * Bankura * Bardhaman * Birbhum * Suri * Cooch Behar * Balurghat* Darjeel G * Daksh D Ajpur* Hooghly* Ch Surah* Howrah * Jalpaiguri * Kalimpong * Kolkata * Maldah* Jhargram * English Bazar * Baharampur * Krishnanagar * Nadia * Murshidabad * Nadia * North 24 Parganas * Barasat * Midnapore * Purba Med Ipur * Tamluk * Purulia * Paschim Med Ipur * Alipore* Raiganj * Uttar D Ajpur * South 24 Parganas * Raiganj
</p>
</marquee> 
</div>
</div>
        </div>
    </section>
    
    <!--Testimonial Section-->
        <!--End Testimonial Section-->
   
    <!--Main Footer-->
     <section class="choose-us">
        <div class="auto-container">
            <div class="row clearfix">
                <div class="column col-lg-12 col-md-12 col-sm-12 col-xs-12 pull-right">
                    <section class="sponsors-style-one">
                            <div class="sponsors-outer">
                                <!--Sponsors Carousel-->
                                <ul class="sponsors-carousel">
								
								 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276267471034650577.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276267901822303391.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276268041572406158.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627626820362909136.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627626835509677227.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276268511441978413.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276268781204677628.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276268931936810359.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627626912386503670.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276269621217650392.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276269771896632416.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276270001428718320.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276270141830269829.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276270282124640587.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276270431147106047.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276270591660916516.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627627073727272821.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276270931597627968.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627627107482648771.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276271231439007269.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627627137241616003.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627627166860178916.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/16276271851122481823.jpg" alt="" style="height:150px;"></figure>
                                    </li>
									 
                                    <li class="slide-item">
                                        <figure class="image-box"><img src="upload/gallery/1627627205669135746.jpg" alt="" style="height:150px;"></figure>
                                    </li>
										
                                    
                                </ul>
                            </div>
                        </section>
                </div>
            </div>
        </div>
    </section></div>
<!--End pagewrapper-->
<footer class="main-footer">
        <!--Footer Upper-->
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-lg-4 col-sm-6 col-xs-12">
                        <div class="footer-widget about-widget">
                            <div class="sec-title-three">
                                <h2>CONTACT US</h2>
                            </div>
                            <div class="text">Gokulshree School Of Management And Technology Private Limited,  Shrawasti -Uttar Pradesh -271831</div>
                            <ul class="about-contact-info">
                                <li><span class="icon flaticon-technology"></span> +91-9628281020</li>
                                <li><span class="icon fa fa-envelope-o"></span> info@gokulshreeschool.com</li>
								<!--<li><span><img src="images/icons/sms.png" alt=""></span> <strong>SMS RUBIX to 8506060000</strong></li>-->
                            </ul>
                        </div>
                        <center>
                        <a href="app-release.apk"><img src="images/applogo.png" style="width:70%;"></a>
                        </center>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget info-links">
                            <div class="sec-title-three">
                                <h2>Quick LINKS</h2>
                            </div>
                            <div class="links-outer">
                                <div class="row clearfix">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="index.php"><span class="fa fa-arrow-right"></span>Home</a></li>
                                            <li><a href="#"><span class="fa fa-arrow-right"></span>About Us</a></li>
                                            <li><a href="photos.php"><span class="fa fa-arrow-right"></span>Photos</a></li>
											<li><a href="videos.php"><span class="fa fa-arrow-right"></span>Videos</a></li>
                                            
                                            <li><a href="payment.php"><span class="fa fa-arrow-right"></span>Make Payment</a></li>
                                            
                                            
                                            
                                            <li><a href="contact-us.php"><span class="fa fa-arrow-right"></span>Contact Us</a></li>
                                            
                                            
											
                                        </ul>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="registration.php"><span class="fa fa-arrow-right"></span>Online Registration</a></li>
                                            <li><a href="verification.php"><span class="fa fa-arrow-right"></span>Student Verification</a></li>
                                        
                                        
                                            <li><a href="login.php"><span class="fa fa-arrow-right"></span>Student Login</a></li>
                                            
                                        <li><a href="download-admitcard.php"><span class="fa fa-arrow-right"></span>Admit Card</a></li>
                                         <li><a href="downloads.php"><span class="fa fa-arrow-right"></span>Downloads</a></li>
                                       <li><a href="result.php"><span class="fa fa-arrow-right"></span>Result</a></li>     
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget">
                            <div class="newsletter-form">
                                <div class="sec-title-three">
                                    <h2>SUBSCRIBE OUR NEWSLETTER</h2>
                                </div>
								                                <form method="post">
                                    <div class="row clearfix">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="name" value="" placeholder="Your Name" required>
                                            </div>
                                        </div>
										<div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="contact" value="" placeholder="Your Mobile No" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Your Email" >
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group button-group">
                                                <button type="submit" name="submit" class="btn-style-two theme-btn">SUBSCRIBE</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Footer Bottom-->
        <div class="auto-container">
            <div class="footer-bottom">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="copyright">Gokulshree School Of Management And Technology Private Limited &copy; 2026 &nbsp; | &nbsp; <a href="privacy-policy.php">Privacy Policy</a>
						
						</div>
                    </div>
                    <!--Column-->
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="social-icons-one pull-right">
                            <ul>
                                <li><a href="https://www.facebook.com/" target="_blank"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="https://twitter.com/" target="_blank"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="https://www.youtube.com/" target="_blank"><span class="fa fa-youtube"></span></a></li>
                                <li><a href="http://www.linkedin.com/" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/revolution.min.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox-media.js"></script>
<script type="text/javascript" src="js/owl.js"></script>
<script type="text/javascript" src="js/wow.js"></script>
<script type="text/javascript" src="js/script.js"></script>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+91-9628281020", // WhatsApp number
            company_logo_url: "//static.whatshelp.io/img/flag.png", // URL of company logo (png, jpg, gif)
            greeting_message: "Hello, how may we help you? Just send us a message now to get assistance.", // Text of greeting message
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>



</div>





</body>
</html>