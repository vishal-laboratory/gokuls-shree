<!DOCTYPE html>
<html>
<head>
<title>Gokulshree School Of Management And Technology Private Limited</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="images/favicon.png">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<META HTTP-EQUIV="EXPIRES" CONTENT="0">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Gokulshree School Of Management And Technology Private Limited is one of the best Institute  in  Shrawasti -Uttar Pradesh -271831 where many of courses are available for students to join for making their career better. Apply Now!">
<meta name="keywords" content="Institutes in  Shrawasti -Uttar Pradesh -271831, Best Institute, Best College, Institute in  Shrawasti -Uttar Pradesh -271831">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/revolution-slider.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/responsive.css">

<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "Gokulshree School Of Management And Technology Private Limited",
  "url": "https://gokulshreeschool.com",
  "sameAs": [
    "https://www.facebook.com/",
    "https://twitter.com",
    "https://linkedin.com/",
    "https://plus.google.com/"
  ],
  "logo": "https://gokulshreeschool.com/images/logo.png",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "+91-9628281020",
    "contactType": "Customer Support :"
  }]
}
</script>

</head>
<body>
<div class="page-wrapper">
<header class="main-header header-style-one">
        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container clearfix">
<!--Top Left-->
 <div class="column col-lg-8 col-md-8 col-sm-12 col-xs-12">
<center>             
<style>
.text-white {
    color: #fff !important;
}
.list-inline {
padding-left: 0;
margin-left: -5px;
list-style: none;
}
.list-inline>li {
    display: inline-block;
    margin-top: 5px;
	 margin-bottom: 5px;
    padding-right: 10px;
  margin-left:4px;
    font-weight: 800;
    background-color:#D9EEE1;
    border-radius: 10px;
}
.pl-10 {
    padding-left: 10px !important;
}
.text-black {
    color: #000 !important;
}
.list-inline>li:hover {
    background: #FFF4A3;
}
					</style>
			<ul class="list-inline sm-pull-none sm-text-center text-white mb-sm-20 mt-10" style="font-size:14px;padding-inline-start: 1px;">
      
			 <li class=" pl-10"><a href="contact-us.php" class="text-black"> Enquiry Here</a></li>
			 <li class=" pl-10"><a href="franchise.php" class="text-black">Franchise Details</a></li>
			  <li class=" pl-10"><a href="franchise-enquiry.php" class="text-black">Apply Franchise</a></li>
			  <li class=" pl-10"><a href="new" target="_blank" class="text-black">Franchise Login</a></li>
			   <li class=" pl-10"><a href="new" target="_blank" class="text-black"> Employee Login</a></li>
			  <li class="pl-10"><a href="login.php" class="text-black">Student Login</a></li>

			  
			 <!--<a href="new" class="text-white m-0 pl-10 mt-0" target="_blank"><span class="btn btn-theme-colored2 btn-xs">Login</span></a>-->  
			 
			 </ul>
             </center>  
				</div>
                <!--Top Right-->
				     <div class="column col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <center>
                    <ul class="links-nav clearfix" style="margin-top:10px;">
                       <li><a href="tell:+91-9628281020" target="_blank" style="color:#fff;"><span class=" fa fa-phone"></span>+91-9628281020</a></li>
                        <li><a href="https://www.facebook.com" target="_blank"><span class=" fa fa-facebook"></span></a></li>
                        <li><a href="https://twitter.com" target="_blank"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="https://www.youtube.com" target="_blank"><span class="fa fa-youtube"></span></a></li>
                        <li><a href="http://www.linkedin.com" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                    </ul>
              </center>
				</div>
            </div>
        </div>
        <!-- Header Top End -->
        <!--Header-Upper-->
        <div class="header-upper">
            <div class="auto-container">
                <div class="clearfix">
                    <div class="pull-left logo-outer">
                        <div class="logo">
						<a href="index.php">
						<img src="images/head.png" alt="Gokulshree School Of Management And Technology Private Limited logo" style="margin-top:5px; margin-bottom:5px;">
						</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
        <!--Header-Lower-->
        <div class="header-lower">
            <div class="auto-container">
                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                        <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                        <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                    <li><a href="verification.php">Student Verification</a></li>
					<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					<li><a href="placement.php">Placement</a></li>
						
						
			
                         </ul>
                                </li>
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                        
                             <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						
						
						
                         </ul>
                                </li>
								<li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                                </li>
								
								
                               
                                
                                <li><a href=""></a></li>
                            
                            	<li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
                             <li><a href="contact-us.php">Contact Us</a></li>
							  <li><a href="find_branch.php">Find Branch</a></li>
							  
						
						
                         </ul>
                                </li>
                            
                            
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                    <div class="btn-outer"><a href="franchise-enquiry.php" class="theme-btn quote-btn"><span class="fa fa-user"></span> Apply Franchise </a></div>
                </div>
            </div>
        </div>
        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.php" class="img-responsive"><img src="images/logo-small.png" alt="Gokulshree School Of Management And Technology Private Limited"></a>
                </div>
                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                      <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                     <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                                      
						<li><a href="verification.php">Student Verification</a></li>
						<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					
						<li><a href="placement.php">Placement</a></li>
                         </ul>
                                </li>
								
									<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                    <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						<li><a href="why_gbge.php">Why GBGE</a></li>
							
						
						
						
                         </ul>
                                </li>
								 <li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
                                 
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                             </li>
                               <li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
							<li><a href="contact-us.php">Contact Us</a></li>
							 <li><a href="find_branch.php">Find Branch</a></li>
							 </ul>
							 </li>
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                </div>
            </div>
        </div>
        <!--End Sticky Header-->
    </header><!--End Main Header -->
<!--Main Slider-->
 <section class="page-title" style="background-image:url(images/page-title.jpg);">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Title -->
                <div class="title-column col-md-6 col-sm-12 col-xs-12">
                    <h1>Centre Verification</h1>
                </div>
                <!--Bread Crumb -->
                <div class="breadcrumb-column col-md-6 col-sm-12 col-xs-12">
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Centre Verification</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--End Page Title-->
    <!--About Section-->
    <section class="about-section">
        <div class="auto-container" style="margin-bottom:50px;">
            <div class="row clearfix">
                <!--Column-->
                <div class="column col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="about-content-box">
                    <div class="row">
                 
<div class="col-lg-12 col-md-12 col-xs-12 thumb">
									<div class="panel panel-default" style="padding:20px;">
									<style>
									.col-md-8{
									margin-top:5px;
									margin-bottom:5px;
									}
									.col-md-4{
									margin-top:5px;
									margin-bottom:5px;
									}
									.col-md-2{
									margin-top:5px;
									margin-bottom:5px;
									}
									</style>
									<div class="row">   
								<div class="col-lg-4 col-md-12">
</div>	
									
									  <style>
		.content-bg {
    width: 100%;
    border: 1px solid #CCC;
    background-color: #FFFFFF;
    border-bottom: 5px solid #CCC;
    padding: 5px 5%;
    margin-bottom: 10px;
    overflow: hidden;
    border-radius: 10px;
}


.row {
    margin-right: -15px;
    margin-left: -15px;
}
.form-group {
    margin-bottom: 15px;
}
.form-control {
    display: block;
    width: 100%;
    height: 34px;
    padding: 6px 12px;

    font-size: 14px;
    line-height: 1.42857143;
    color: #555;
    background-color: #fff;
    background-image: none;
border: 1px solid #ccc;}
.btnnew {
    -webkit-transition: 0.5s;
    transition: 0.5s;
    display: inline-block;
    padding: 13px 25px 12px 25px;
    position: relative;
    background-color: #154979;
    color: #ffffff;
    border-width: 2px;
    border-style: solid;
    border-color: #fff;
    border-radius: 1px;
    font-size: 14.5px;
    font-weight: 700;
}
		</style>
		
		<div class="col-lg-4 col-md-12">
			
				
				<div class="login content-bg">
<center>
<h3>Verify Centre </h3>
<form  style="width:100%; margin-left:2%;" id="sky-form" class="sky-fosrm" method="post" onSubmit="return validateLoginForm()" novalidate="novalidate">	
<div class="row">
<div class="form-group col-12">
<lable style="text-align:left;">search Code</lable>
<input class="form-control" name="bcode" id="bcode" type="text" value="" style="text-align:center;">
</div>

<div class="form-group col-12">
<input  name="go" type="submit" id="submit" value="Verify" class="btnnew">
<a href="index.php">
<input  name="cancel" type="button" id="cancel" value="Cancel" class="btnnew">
</a>
</div>
</div>
</form>
</center>
	
				
				
				
			</div>					
        </div>	

<div class="col-lg-4 col-md-12">
</div>		
</div>


<p style="text-align:center;color:#FF0000;margin-top:10px; font-size:18px;">Record Not Found......</p>
</div>
</div>
               
            </div>
        </div>
		</div>
    </section>


<footer class="main-footer">
        <!--Footer Upper-->
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-lg-4 col-sm-6 col-xs-12">
                        <div class="footer-widget about-widget">
                            <div class="sec-title-three">
                                <h2>CONTACT US</h2>
                            </div>
                            <div class="text">Gokulshree School Of Management And Technology Private Limited,  Shrawasti -Uttar Pradesh -271831</div>
                            <ul class="about-contact-info">
                                <li><span class="icon flaticon-technology"></span> +91-9628281020</li>
                                <li><span class="icon fa fa-envelope-o"></span> info@gokulshreeschool.com</li>
								<!--<li><span><img src="images/icons/sms.png" alt=""></span> <strong>SMS RUBIX to 8506060000</strong></li>-->
                            </ul>
                        </div>
                        <center>
                        <a href="app-release.apk"><img src="images/applogo.png" style="width:70%;"></a>
                        </center>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget info-links">
                            <div class="sec-title-three">
                                <h2>Quick LINKS</h2>
                            </div>
                            <div class="links-outer">
                                <div class="row clearfix">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="index.php"><span class="fa fa-arrow-right"></span>Home</a></li>
                                            <li><a href="#"><span class="fa fa-arrow-right"></span>About Us</a></li>
                                            <li><a href="photos.php"><span class="fa fa-arrow-right"></span>Photos</a></li>
											<li><a href="videos.php"><span class="fa fa-arrow-right"></span>Videos</a></li>
                                            
                                            <li><a href="payment.php"><span class="fa fa-arrow-right"></span>Make Payment</a></li>
                                            
                                            
                                            
                                            <li><a href="contact-us.php"><span class="fa fa-arrow-right"></span>Contact Us</a></li>
                                            
                                            
											
                                        </ul>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="registration.php"><span class="fa fa-arrow-right"></span>Online Registration</a></li>
                                            <li><a href="verification.php"><span class="fa fa-arrow-right"></span>Student Verification</a></li>
                                        
                                        
                                            <li><a href="login.php"><span class="fa fa-arrow-right"></span>Student Login</a></li>
                                            
                                        <li><a href="download-admitcard.php"><span class="fa fa-arrow-right"></span>Admit Card</a></li>
                                         <li><a href="downloads.php"><span class="fa fa-arrow-right"></span>Downloads</a></li>
                                       <li><a href="result.php"><span class="fa fa-arrow-right"></span>Result</a></li>     
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget">
                            <div class="newsletter-form">
                                <div class="sec-title-three">
                                    <h2>SUBSCRIBE OUR NEWSLETTER</h2>
                                </div>
								                                <form method="post">
                                    <div class="row clearfix">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="name" value="" placeholder="Your Name" required>
                                            </div>
                                        </div>
										<div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="contact" value="" placeholder="Your Mobile No" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Your Email" >
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group button-group">
                                                <button type="submit" name="submit" class="btn-style-two theme-btn">SUBSCRIBE</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Footer Bottom-->
        <div class="auto-container">
            <div class="footer-bottom">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="copyright">Gokulshree School Of Management And Technology Private Limited &copy; 2026 &nbsp; | &nbsp; <a href="privacy-policy.php">Privacy Policy</a>
						
						</div>
                    </div>
                    <!--Column-->
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="social-icons-one pull-right">
                            <ul>
                                <li><a href="https://www.facebook.com/" target="_blank"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="https://twitter.com/" target="_blank"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="https://www.youtube.com/" target="_blank"><span class="fa fa-youtube"></span></a></li>
                                <li><a href="http://www.linkedin.com/" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/revolution.min.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox-media.js"></script>
<script type="text/javascript" src="js/owl.js"></script>
<script type="text/javascript" src="js/wow.js"></script>
<script type="text/javascript" src="js/script.js"></script>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+91-9628281020", // WhatsApp number
            company_logo_url: "//static.whatshelp.io/img/flag.png", // URL of company logo (png, jpg, gif)
            greeting_message: "Hello, how may we help you? Just send us a message now to get assistance.", // Text of greeting message
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
  
</body>
</html>