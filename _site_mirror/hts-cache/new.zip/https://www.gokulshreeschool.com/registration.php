<!DOCTYPE html>
<html>
<head>
<title>Gokulshree School Of Management And Technology Private Limited</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="shortcut icon" href="images/favicon.png">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
<META HTTP-EQUIV="EXPIRES" CONTENT="0">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Gokulshree School Of Management And Technology Private Limited is one of the best Institute  in  Shrawasti -Uttar Pradesh -271831 where many of courses are available for students to join for making their career better. Apply Now!">
<meta name="keywords" content="Institutes in  Shrawasti -Uttar Pradesh -271831, Best Institute, Best College, Institute in  Shrawasti -Uttar Pradesh -271831">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/revolution-slider.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/responsive.css">

<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "name": "Gokulshree School Of Management And Technology Private Limited",
  "url": "https://gokulshreeschool.com",
  "sameAs": [
    "https://www.facebook.com/",
    "https://twitter.com",
    "https://linkedin.com/",
    "https://plus.google.com/"
  ],
  "logo": "https://gokulshreeschool.com/images/logo.png",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "+91-9628281020",
    "contactType": "Customer Support :"
  }]
}
</script>
<script type="text/javascript">
function getXMLHTTP() { 
		var xmlhttp=false;	
		try{
			xmlhttp=new XMLHttpRequest();
		}
		catch(e)	{		
			try{			
				xmlhttp= new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e){
				try{
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
				}
				catch(e1){
					xmlhttp=false;
				}
			}
		}
		 	
		return xmlhttp;
    }
	
	function find_courses(subid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_courses.php?cid="+subid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('courses_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}
function find_batch(batchid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_batch.php?bid="+batchid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('batch_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}

	function find_district(subid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_district.php?cid="+subid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('district_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}
	
	function find_branch(subid) {
		//alert(subid);	
	   //var cid=document.getElementById("category").value;	
		var strURL="find_branch_web.php?cid="+subid;
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						document.getElementById('branch_div').innerHTML=req.responseText;
						//alert("OK");						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}



</script>
</head>
<body>
<div class="page-wrapper">
<header class="main-header header-style-one">
        <!-- Header Top -->
        <div class="header-top">
            <div class="auto-container clearfix">
<!--Top Left-->
 <div class="column col-lg-8 col-md-8 col-sm-12 col-xs-12">
<center>             
<style>
.text-white {
    color: #fff !important;
}
.list-inline {
padding-left: 0;
margin-left: -5px;
list-style: none;
}
.list-inline>li {
    display: inline-block;
    margin-top: 5px;
	 margin-bottom: 5px;
    padding-right: 10px;
  margin-left:4px;
    font-weight: 800;
    background-color:#D9EEE1;
    border-radius: 10px;
}
.pl-10 {
    padding-left: 10px !important;
}
.text-black {
    color: #000 !important;
}
.list-inline>li:hover {
    background: #FFF4A3;
}
					</style>
			<ul class="list-inline sm-pull-none sm-text-center text-white mb-sm-20 mt-10" style="font-size:14px;padding-inline-start: 1px;">
      
			 <li class=" pl-10"><a href="contact-us.php" class="text-black"> Enquiry Here</a></li>
			 <li class=" pl-10"><a href="franchise.php" class="text-black">Franchise Details</a></li>
			  <li class=" pl-10"><a href="franchise-enquiry.php" class="text-black">Apply Franchise</a></li>
			  <li class=" pl-10"><a href="new" target="_blank" class="text-black">Franchise Login</a></li>
			   <li class=" pl-10"><a href="new" target="_blank" class="text-black"> Employee Login</a></li>
			  <li class="pl-10"><a href="login.php" class="text-black">Student Login</a></li>

			  
			 <!--<a href="new" class="text-white m-0 pl-10 mt-0" target="_blank"><span class="btn btn-theme-colored2 btn-xs">Login</span></a>-->  
			 
			 </ul>
             </center>  
				</div>
                <!--Top Right-->
				     <div class="column col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <center>
                    <ul class="links-nav clearfix" style="margin-top:10px;">
                       <li><a href="tell:+91-9628281020" target="_blank" style="color:#fff;"><span class=" fa fa-phone"></span>+91-9628281020</a></li>
                        <li><a href="https://www.facebook.com" target="_blank"><span class=" fa fa-facebook"></span></a></li>
                        <li><a href="https://twitter.com" target="_blank"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="https://www.youtube.com" target="_blank"><span class="fa fa-youtube"></span></a></li>
                        <li><a href="http://www.linkedin.com" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                    </ul>
              </center>
				</div>
            </div>
        </div>
        <!-- Header Top End -->
        <!--Header-Upper-->
        <div class="header-upper">
            <div class="auto-container">
                <div class="clearfix">
                    <div class="pull-left logo-outer">
                        <div class="logo">
						<a href="index.php">
						<img src="images/head.png" alt="Gokulshree School Of Management And Technology Private Limited logo" style="margin-top:5px; margin-bottom:5px;">
						</a>
						</div>
                    </div>
                </div>
            </div>
        </div>
        <!--Header-Lower-->
        <div class="header-lower">
            <div class="auto-container">
                <div class="nav-outer clearfix">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                        <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                        <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                    <li><a href="verification.php">Student Verification</a></li>
					<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					<li><a href="placement.php">Placement</a></li>
						
						
			
                         </ul>
                                </li>
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                        
                             <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						
						
						
                         </ul>
                                </li>
								<li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                                </li>
								
								
                               
                                
                                <li><a href=""></a></li>
                            
                            	<li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
                             <li><a href="contact-us.php">Contact Us</a></li>
							  <li><a href="find_branch.php">Find Branch</a></li>
							  
						
						
                         </ul>
                                </li>
                            
                            
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                    <div class="btn-outer"><a href="franchise-enquiry.php" class="theme-btn quote-btn"><span class="fa fa-user"></span> Apply Franchise </a></div>
                </div>
            </div>
        </div>
        <!--Sticky Header-->
        <div class="sticky-header">
            <div class="auto-container clearfix">
                <!--Logo-->
                <div class="logo pull-left">
                    <a href="index.php" class="img-responsive"><img src="images/logo-small.png" alt="Gokulshree School Of Management And Technology Private Limited"></a>
                </div>
                <!--Right Col-->
                <div class="right-col pull-right">
                    <!-- Main Menu -->
                    <nav class="main-menu">
                        <div class="navbar-header">
                            <!-- Toggle Button -->
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse clearfix">
                            <ul class="navigation clearfix">
                                <li class="current"><a href="index.php">Home</a></li>
                                                                       <li class="dropdown">
                                            <a href="javascript:return(0);">Student </a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TXpVPQ==">Registration Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpZPQ==">Examination Process</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TXpjPQ==">Placement</a></li>
                                                
                                                                                             </ul>
											 
											                                        <li class="dropdown">
                                            <a href="javascript:return(0);">About Us</a>
											 
                                            <ul>
											                                                <li><a href="page.php?id=TVRnPQ==">Our Profile</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TVRrPQ==">Chairman Message</a></li>
                                                
                                                                                                 <li><a href="page.php?id=TWpBPQ==">Our Vision & Mission</a></li>
                                                
                                                                                             </ul>
											 
											                                        </li>
										
                                        <li class="dropdown">
                                            <a href="javascript:return(0);">Courses</a>
											
                                            <ul>
											                                                <li><a href="courses.php?cid=TVE9PQ==">Diploma Courses </a></li>
                                                                                                <li><a href="courses.php?cid=TkE9PQ==">Vocational Courses</a></li>
                                                                                                <li><a href="courses.php?cid=TlE9PQ==">YOGA Courses</a></li>
                                                                                                <li><a href="courses.php?cid=T1E9PQ==">University Courses</a></li>
                                                  
                                         
                                    </ul>
                                </li>
								
                                <li class="dropdown">
                                    <a href="javascript:return(0);">Student Zone</a>
                                    <ul>
                                      <li><a href="registration_process.php">Registration Process</a></li>
                                        
                                        <li><a href="examination_process.php">Examination Process</a></li>
                                        
                                       <li><a href="registration.php">  Student Registration</a></li>
                                       <li><a href="download-admitcard.php">  Admit Card</a></li>
                                     <li><a href="marksheet-verification.php">Marksheet verification</a></li>
                                        <li><a href="certificate-verification.php">Certificate Verification</a></li>
                                      
						<li><a href="verification.php">Student Verification</a></li>
						<li><a href="login.php">Student Login</a></li>
					<li><a href="login.php">Online Exam</a></li>
					
						<li><a href="placement.php">Placement</a></li>
                         </ul>
                                </li>
								
									<li class="dropdown">
                                    <a href="javascript:return(0);">Franchise</a>
                                    <ul>
                                    <li><a href="franchise-enquiry.php">Apply Online</a></li> 
                                    <li><a href="centre-verification.php">Centre Verification</a></li>
                             <li><a href="franchise.php">Get Franchise</a></li>
						<li><a href="why_gbge.php">Why GBGE</a></li>
							
						
						
						
                         </ul>
                                </li>
								 <li><a href="publications.php">Our Publications</a></li>
								<li class="dropdown">
                                    <a href="javascript:return(0);">Gallery</a>
                                    <ul>
                             <li><a href="photos.php">Photos</a></li>
						<li><a href="videos.php">Videos</a></li>
						
                         </ul>
                                </li>
                                
                                 
								
								<li class="dropdown">
                                    <a href="javascript:return(0);">Login</a>
                                    <ul>
                             <li><a href="new" target="_blank">Admin Login</a></li>
							  <li><a href="new" target="_blank">Franchise Login</a></li>
							  <li><a href="new" target="_blank">Employee Login</a></li>
							  <li><a href="login.php" >Student Login</a></li>
							   <li><a href="webmail" target="_blank">Webmail Login</a></li>
						
						
                         </ul>
                             </li>
                               <li class="dropdown">
                                    <a href="javascript:return(0);">Contact</a>
                                    <ul>
							<li><a href="contact-us.php">Contact Us</a></li>
							 <li><a href="find_branch.php">Find Branch</a></li>
							 </ul>
							 </li>
                            </ul>
                        </div>
                    </nav>
                    <!-- Main Menu End-->
                </div>
            </div>
        </div>
        <!--End Sticky Header-->
    </header><!--End Main Header -->
<!--Main Slider-->
 <section class="page-title" style="background-image:url(images/page-title.jpg);">
        <div class="auto-container">
            <div class="row clearfix">
                <!--Title -->
                <div class="title-column col-md-6 col-sm-12 col-xs-12">
                    <h1>Online Registration</h1>
                </div>
                <!--Bread Crumb -->
                <div class="breadcrumb-column col-md-6 col-sm-12 col-xs-12">
                    <ul class="bread-crumb clearfix">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Online Registration</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--End Page Title-->
    <!--About Section-->
    <section class="about-section">
        <div class="auto-container" style="background: #CCCCCC;
    margin-bottom: 80px;
    padding: 20px;
    box-shadow: 0px 0px 10px 0px rgb(0 0 0 / 50%);">
            <div class="row clearfix">
                <!--Column-->
                <div class="column col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="about-content-box">
                        
                      <div class="row">
<div class="col-lg-12">
<form method="post" enctype="multipart/form-data" name="form1"	style="padding:15px;">
<input type="hidden" value="" name="refer" >
<input name="username" type="hidden" id="username" value="1">			
<input type="hidden" name="uid" value="1">
<input type="hidden" name="branch" value="">
<input type="hidden" name="pid" value="">
<input type="hidden" name="cid" value="">
<div id="page-inner">
<div class="row">
<style>
.col-md-6{
margin-top:5px;
margin-bottom:5px;
}

.col-md-12{
margin-top:5px;
margin-bottom:5px;
}

.col-md-4{
margin-top:5px;
margin-bottom:5px;
}

</style>
<div class="row"  style=" border-bottom:dotted 2px #FF0000;">
<h3 style="color:#990000">Choose Your Location</h3>
</div>
<div class="row">

<div class="col-md-6" style="margin-top:10px;">
<strong style="color:#003366;"> STATE</strong><br>


<select onChange="find_district(this.value)"  name="state" class="form-control"  >
<option value="">Select</option>
<option value="1" >Andaman and Nicobar Island (UT)</option>
<option value="2" >Andhra Pradesh</option>
<option value="3" >Arunachal Pradesh</option>
<option value="4" >Assam</option>
<option value="5" >Bihar</option>
<option value="6" >Chandigarh (UT)</option>
<option value="7" >Chhattisgarh</option>
<option value="8" >Dadra and Nagar Haveli (UT)</option>
<option value="9" >Daman and Diu (UT)</option>
<option value="10" >Delhi (NCT)</option>
<option value="11" >Goa</option>
<option value="12" >Gujarat</option>
<option value="13" >Haryana</option>
<option value="14" >Himachal Pradesh</option>
<option value="15" >Jammu and Kashmir</option>
<option value="16" >Jharkhand</option>
<option value="17" >Karnataka</option>
<option value="18" >Kerala</option>
<option value="19" >Lakshadweep (UT)</option>
<option value="20" >Madhya Pradesh</option>
<option value="21" >Maharashtra</option>
<option value="22" >Manipur</option>
<option value="23" >Meghalaya</option>
<option value="24" >Mizoram</option>
<option value="25" >Nagaland</option>
<option value="26" >Odisha</option>
<option value="27" >Puducherry (UT)</option>
<option value="28" >Punjab</option>
<option value="29" >Rajastha</option>
<option value="30" >Sikkim</option>
<option value="31" >Tamil Nadu</option>
<option value="32" >Telangana</option>
<option value="33" >Tripura</option>
<option value="34" >Uttarakhand</option>
<option value="35" >Uttar Pradesh</option>
<option value="36" >West Bengal</option>
</select>							
<span class="red" style="color:red;"> </span>              
</div>
<div class="col-md-6" style="margin-top:10px;"><strong style="color:#003366;"> DISTRICT</strong><br>
<div id="district_div">
<select name="district" style="padding:5px;"  class="form-control" tabindex="18" onChange="find_branch(this.value)">
<option value="">Select</option>
</select>

<span class="red" style="color:red;">  </span>

</div>
</div>
</div>

<div class="row">
<div class="col-lg-6 col-md-6">
<strong style="color:#003366; margin-top:10px;">Select Your Study Centre </strong>
<div id="branch_div">
<select name="branch" class="form-control" > 
<option value="">--  BRANCH --</option>
<option value="1" >
GOKUL-Gokulshree School Of Management And Technology Private Limited<br>(Gilaula Road Laxman Nagar Shrawasti -Uttar Pradesh -271804)</option>
<option value="144" >
GOKUL003-Rajveer Singh Computer Training Centre <br>(Station Road Matera Chauraha Bahraich Uttar Pradesh Pin Code - 271882 IN)</option>
<option value="146" >
GO110210825-Gokulshree School Of Management And Technology Private Limited<br>(Near Vikas Bhavan Civil Line Baguraiya Mod Bhinga Shravasti (U.P.) 271831)</option>
<option value="147" >
GO10011002024-Sanjeet  Jaiswal Computer Training Centre<br>(Khutehana Bajar Bahraich Uttar Pradesh - 271870)</option>
<option value="148" >
GO05700251025-MAA SARASWATI COMPUTER CENTRE <br>(SEMRI CHAURAHA BHINGA SHRAWASTI UTTAR PRADESH - 271831)</option>
</select>
</div>
<span class="red" style="color:red;"> </span>  
</div>

<div class="col-md-6"><strong style="color:#003366;">Select Your Religion</strong><br/>
<select name="religion"   class="form-control"   tabindex="6">
<option value="">Select</option>
<option value="Hinduism"  >Hinduism</option>
<option value="Islam"  >Islam</option>
<option value="Christian"  >Christian </option>
<option value="Other"  >Other</option>
</select> 
<span class="red" style="color:red;"> </span>   
</div>

</div>
                                        
<div class="row"  style=" border-bottom:dotted 2px #FF0000; margin-top:5px;margin-bottom:5px;">
<h3 style="color:#990000">Choose Your Course</h3>
</div>

<div class="row">
<div class="col-md-4"><strong style="color:#003366;">Course Category</strong>
<select name="program" onChange="find_courses(this.value)" class="form-control" tabindex="13">
<option selected="selected" value="0">Select Course Category</option>
<option value="1" >Diploma Courses </option>
<option value="4" >Vocational Courses</option>
<option value="5" >YOGA Courses</option>
<option value="9" >University Courses</option>
</select>
<span class="red" style="color:red;"> </span> 
</div>

<div class="col-md-4"><strong style="color:#003366;">Course Name</strong>
<span id="courses_div">
<select name="courses" class="form-control" tabindex="14" >
<option value="">Select Course</option>
</select>
</span>
<span class="red" style="color:red;"> </span> 
</div>

<div class="col-md-4"><strong style="color:#003366;">Choose Your Session</strong>
<select name="asession" style="padding:5px;" id="ddlstgender" class="form-control" tabindex="9">
<option value="">Select Session</option>
<option value="2009"  selected="selected">2009-2010</option><option value="2010"  selected="selected">2010-2011</option><option value="2011"  selected="selected">2011-2012</option><option value="2012"  selected="selected">2012-2013</option><option value="2013"  selected="selected">2013-2014</option><option value="2014"  selected="selected">2014-2015</option><option value="2015"  selected="selected">2015-2016</option><option value="2016"  selected="selected">2016-2017</option><option value="2017"  selected="selected">2017-2018</option><option value="2018"  selected="selected">2018-2019</option><option value="2019"  selected="selected">2019-2020</option><option value="2020"  selected="selected">2020-2021</option><option value="2021"  selected="selected">2021-2022</option></select>
<span  style="color:red;"></span>
</div>

</div>

<div class="row"  style=" border-bottom:dotted 2px #FF0000;margin-top:5px;margin-bottom:5px;">
<h3 style="color:#990000">Personal Information</h3>
</div>

<div class="row">
<div class="col-md-4"><strong style="color:#003366;">Your Full Name</strong>
<input name="name" value=""  type="text" id="txtfname" class="form-control" tabindex="1">
<span class="red" style="color:red;"> </span> 
</div>

<div class="col-md-4"><strong style="color:#003366;">Father's Name</strong>
<input name="father"   value="" type="text" id="txtfathername" class="form-control" tabindex="2">
<span class="red" style="color:red;"> </span>   
</div>

<div class="col-md-4"><strong style="color:#003366;">Mother's Name</strong>
<input name="mother"   value="" type="text" id="txtfathername" class="form-control" tabindex="3">
<span class="red" style="color:red;"> </span>   
</div>
</div>
<div class="row">

<div class="col-md-4"><strong style="color:#003366;">Date of Birth</strong>
<input name="dob" value="" type="date" id="txtfathername" class="form-control" tabindex="4">
<span class="red" style="color:red;"> </span>   
</div>

<div class="col-md-4"><strong style="color:#003366;">Gender</strong>
<select name="gender" id="ddlstgender"  class="form-control" tabindex="5">
<option value="0">Select Gender</option>
<option value="Male" >Male</option>
<option value="Female" >Female</option>
</select>
<span class="red" style="color:red;"> </span> 
</div>
<div class="col-md-4"><strong style="color:#003366;">Category</strong><br/>
<select name="category"   class="form-control"   tabindex="6">
<option value="">Select</option>
<option value="SC"  >SC</option>
<option value="ST"  >ST</option>
<option value="GEN"  >GEN</option>
<option value="OBC"  >OBC</option>
</select> 
<span class="red" style="color:red;"> </span>   
</div>

</div>
<div class="row">

<div class="col-md-4"><strong style="color:#003366;">Marital Status</strong><br/>
<select name="marital"   class="form-control"   tabindex="6">
<option value="">Select</option>
<option value="Married"  >Married</option>
<option value="Unmarried"  >Unmarried</option>
</select> 
<span class="red" style="color:red;"> </span>   
</div>

<div class="col-md-4"><strong style="color:#003366;">Choose Your  Identity Type</strong><br/>
<select name="identity_type"   class="form-control"   tabindex="6">
<option value="">Select</option>
<option value="Adhar Card"  >Adhar Card</option>
<option value="Voter ID"  >Voter ID</option>
<option value="Other"  >Other</option>
</select> 
<span class="red" style="color:red;"> </span>  
</div>

<div class="col-md-4"><strong style="color:#003366;">Id Number</strong>
<input name="idnumber" maxlength="12"  type="text" value="" id="txtfathername" class="form-control" tabindex="7">
<span class="red" style="color:red;"> </span>  
</div>

</div>
                                
<div class="row">

<div class="col-md-4"><strong style="color:#003366;">Last General Qualification</strong>
<select name="qui"  class="form-control" tabindex="8" >
<option value="">Select</option>
<option  value="8th">8th</option>
<option  value="10th">10th</option>
<option value="12th" >12th</option>
<option value="Graduation" >Graduation</option>
<option value="Post Graduation" > Post Graduation</option>
<option  value="Others">Others</option>
</select> 
<span class="red" style="color:red;"> </span>   
</div>


<div class="col-md-4"><strong style="color:#003366;">Contact Number</strong>
<input name="contact" maxlength="10"  type="text" value="" id="txtfathername" class="form-control" tabindex="11">
<span class="red" style="color:red;"> </span>   
</div>

<div class="col-md-4"><strong style="color:#003366;">Email Account</strong> 
<input name="email"  type="text"  id="email" value="" class="form-control" tabindex="12">
</div>

</div>
<div class="row">
<div class="col-md-4" style=""><strong style="color:#003366;">Address </strong>

<textarea name="address" type="text" class="form-control" tabindex="15"></textarea>

<span class="red" style="color:red;"> </span> 
</div>

<div class="col-md-4"><strong style="color:#003366;">PINCODE </strong>
<input name="pincode" maxlength="6" value="" type="text"  id="txtcadd1" class="form-control" tabindex="19">
<span class="red" style="color:red;"> </span> 
</div>


<div class="col-md-4"><strong style="color:#003366;">Enquiry Source</strong>
<select name="enquiry_source"  class="form-control" tabindex="8" >
<option value="">Select</option>
<option  value="Banner">Banner</option>
<option value="Liflet" >Liflet</option>
<option value="Poster" >Poster</option>
<option value="News_Paper" > News Paper</option>
<option value="SMS" > SMS</option>
<option value="Counseling_Centre" > Counseling Centre</option>
</select> 
<span class="red" style="color:red;"> </span>   
</div>


</div>



<div class="row"><br/>
<div class="col-md-12"><strong style="color:#003366; font-size:18px;">VERIFICATION CODE</strong></div>

<div class="col-md-4">Enter Verification code</div>
<div class="col-md-4"><input name="vercode" type="text" id="TextBoxRegCode" class="form-control" tabindex="20" required>
<span class="red" style="color:red;"> </span></div>
<div class="col-md-4"><img src="captcha.php" style="padding:5px;"></div>
</div> 

<div class="row">
<div class="col-md-12 headerTitle"><strong>DECLARATION BY STUDENT</strong></div>
<div class="col-md-12 headerTitle"><p align="justify"> I hereby declare that all the above statements are true and correct the best of my knowledge and belief. I shall obey all the Rules and Regulations of the organization.

</p>
</div>
</div>
<div class="row">
<div class="col-md-12" align="center"><button type="submit" class="btn" name="go" style="color: #ffffff; background-color: #2196f3;" tabindex="21"> Register Me </button></div>
</div>

</form>  
                       
                </div>
                </div>
               
            </div>
        </div>
    </section>


<footer class="main-footer">
        <!--Footer Upper-->
        <div class="footer-upper">
            <div class="auto-container">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-lg-4 col-sm-6 col-xs-12">
                        <div class="footer-widget about-widget">
                            <div class="sec-title-three">
                                <h2>CONTACT US</h2>
                            </div>
                            <div class="text">Gokulshree School Of Management And Technology Private Limited,  Shrawasti -Uttar Pradesh -271831</div>
                            <ul class="about-contact-info">
                                <li><span class="icon flaticon-technology"></span> +91-9628281020</li>
                                <li><span class="icon fa fa-envelope-o"></span> info@gokulshreeschool.com</li>
								<!--<li><span><img src="images/icons/sms.png" alt=""></span> <strong>SMS RUBIX to 8506060000</strong></li>-->
                            </ul>
                        </div>
                        <center>
                        <a href="app-release.apk"><img src="images/applogo.png" style="width:70%;"></a>
                        </center>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget info-links">
                            <div class="sec-title-three">
                                <h2>Quick LINKS</h2>
                            </div>
                            <div class="links-outer">
                                <div class="row clearfix">
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="index.php"><span class="fa fa-arrow-right"></span>Home</a></li>
                                            <li><a href="#"><span class="fa fa-arrow-right"></span>About Us</a></li>
                                            <li><a href="photos.php"><span class="fa fa-arrow-right"></span>Photos</a></li>
											<li><a href="videos.php"><span class="fa fa-arrow-right"></span>Videos</a></li>
                                            
                                            <li><a href="payment.php"><span class="fa fa-arrow-right"></span>Make Payment</a></li>
                                            
                                            
                                            
                                            <li><a href="contact-us.php"><span class="fa fa-arrow-right"></span>Contact Us</a></li>
                                            
                                            
											
                                        </ul>
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                        <ul>
                                            <li><a href="registration.php"><span class="fa fa-arrow-right"></span>Online Registration</a></li>
                                            <li><a href="verification.php"><span class="fa fa-arrow-right"></span>Student Verification</a></li>
                                        
                                        
                                            <li><a href="login.php"><span class="fa fa-arrow-right"></span>Student Login</a></li>
                                            
                                        <li><a href="download-admitcard.php"><span class="fa fa-arrow-right"></span>Admit Card</a></li>
                                         <li><a href="downloads.php"><span class="fa fa-arrow-right"></span>Downloads</a></li>
                                       <li><a href="result.php"><span class="fa fa-arrow-right"></span>Result</a></li>     
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Column-->
                    <div class="column col-md-4 col-sm-6 col-xs-12">
                        <div class="footer-widget">
                            <div class="newsletter-form">
                                <div class="sec-title-three">
                                    <h2>SUBSCRIBE OUR NEWSLETTER</h2>
                                </div>
								                                <form method="post">
                                    <div class="row clearfix">
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="name" value="" placeholder="Your Name" required>
                                            </div>
                                        </div>
										<div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="text" name="contact" value="" placeholder="Your Mobile No" required>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="email" name="email" value="" placeholder="Your Email" >
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group button-group">
                                                <button type="submit" name="submit" class="btn-style-two theme-btn">SUBSCRIBE</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Footer Bottom-->
        <div class="auto-container">
            <div class="footer-bottom">
                <div class="row clearfix">
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="copyright">Gokulshree School Of Management And Technology Private Limited &copy; 2026 &nbsp; | &nbsp; <a href="privacy-policy.php">Privacy Policy</a>
						
						</div>
                    </div>
                    <!--Column-->
                    <!--Column-->
                    <div class="column col-md-6 col-sm-6 col-xs-12">
                        <div class="social-icons-one pull-right">
                            <ul>
                                <li><a href="https://www.facebook.com/" target="_blank"><span class="fa fa-facebook"></span></a></li>
                                <li><a href="https://twitter.com/" target="_blank"><span class="fa fa-twitter"></span></a></li>
                                <li><a href="https://www.youtube.com/" target="_blank"><span class="fa fa-youtube"></span></a></li>
                                <li><a href="http://www.linkedin.com/" target="_blank"><span class="fa fa-linkedin"></span></a></li>
                                
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-long-arrow-up"></span></div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/revolution.min.js"></script>
<script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
<script type="text/javascript" src="js/jquery.fancybox-media.js"></script>
<script type="text/javascript" src="js/owl.js"></script>
<script type="text/javascript" src="js/wow.js"></script>
<script type="text/javascript" src="js/script.js"></script>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+91-9628281020", // WhatsApp number
            company_logo_url: "//static.whatshelp.io/img/flag.png", // URL of company logo (png, jpg, gif)
            greeting_message: "Hello, how may we help you? Just send us a message now to get assistance.", // Text of greeting message
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
  
</body>
</html>